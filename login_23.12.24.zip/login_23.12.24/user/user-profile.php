<link rel="icon" href="fevicon.png"/>
<?php
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');

$userid=$_GET['uid'];

if(isset($_POST['submit'])){
    
$target_path = "userbillsubmitted/";
$target_path = $target_path.basename($_FILES['fileToUpload']['name']);  

if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) {  
    echo "<script>alert('Your form has been submitted successfully.')</script>"; 
    // print_r($_FILES); 
 
} else{  
    echo "<script>alert('Your form has not been submitted successfully.')</script>";
}

 $fnam=$_FILES['fileToUpload']['name'];
 $result=mysqli_query($con,"update travel_data set document_name='$fnam' where tid='$userid'");

}


$query=mysqli_query($con,"select * from travel_data where tid='$userid'");
while($result=mysqli_fetch_array($query))


{?>

                        <div class="card mb-4">
                        <!-- <h5 class="mt-2"><?php echo $result['name'];?>'s TA Bill</h5> -->
                            <div class="card-body" style=" background:linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),url('aucb_wm.png') no-repeat;
                             background-position: center; background-size:45%;">
                                
                                <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                    <strong><p style="font-size:20px;text-decoration: underline;">User Details:</p></strong>
                                    <table class="table table-bordered table-striped">
                                        <tr>
                                        <th>First Name:</th>
                                        <td><?php echo $result['first_name']; ?></td>
                                        </tr>
                                        <tr>
                                        <th>Last Name:</th>
                                        <td><?php echo $result['last_name']; ?></td>
                                        </tr>
                                        <tr>
                                        <th>Branch:</th>
                                        <td><?php echo $result['branch']; ?></td>
                                        </tr>
                                        <tr>
                                        <th>Designation:</th>
                                        <td><?php echo $result['designation']; ?></td>                                        
                                        </tr>
                                        <tr>
                                        <th>Passing Officer:</th>
                                        <td><?php echo $result['passing_officer']; ?></td>
                                        </tr>
                                    </table>
                                    </div  >
                                   
                                </div>
                                </div>

                                <strong><p style="font-size:20px;text-decoration: underline;">Travel Details:</p></strong>
                                <table class="table table-bordered table-striped" >
                                   

                                    <thead>
                                        <tr>
                                        <th scope="col">City Type</th>    
                                        <th scope="col">Depa. Date & Time</th>
                                        <th scope="col">From Station</th>
                                        <th scope="col">Arrival Date & Time</th>
                                        <th scope="col">To Station</th>                                        
                                        <th scope="col">Kilometer</th>
                                        <th scope="col">Days</th>
                                        <th scope="col">Rate</th>
                                        <th scope="col">DA Charges</th>
                                        <th scope="col">Lodging Charges</th>                                        
                                        <th scope="col">Conveyance Charges</th>
                                        <th scope="col">Bus/Railway Fare</th>
                                        
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['p1_citytype'];?></td>     
                                        <td><?php echo $result['p1_startdate'];?></td>
                                        <td><?php echo $result['p1_fromstation'];?></td>
                                        <td><?php echo $result['p1_enddate'];?></td>
                                        <td><?php echo $result['p1_tostation'];?></td>                                        
                                        <td><?php echo $result['p1_km'];?>&nbsp;km</td>
                                        <td ><?php echo $result['p1_totaldays'];?></td>
                                        <td ><?php echo $result['p1_darate'];?></td>
                                        <td><?php echo $result['p1_dacharges'];?></td>
                                        <td><?php echo $result['p1_lccharges'];?></td>
                                        <td><?php echo $result['p1_cccharges'];?></td> 
                                        <td><?php echo $result['p1_ticketamount'];?></td>                                        
                                        </tr>
                                      <?php  if (!empty($result['p2_citytype'])){?>
                                        <tr>
                                        <td><?php echo $result['p2_citytype'];?></td>     
                                        <td><?php echo $result['p2_startdate'];?></td>
                                        <td><?php echo $result['p2_fromstation'];?></td>
                                        <td><?php echo $result['p2_enddate'];?></td>
                                        <td><?php echo $result['p2_tostation'];?></td>                                        
                                        <td><?php echo $result['p2_km'];?>&nbsp;km</td>
                                        <td ><?php echo $result['p2_totaldays'];?></td>
                                        <td ><?php echo $result['p2_darate'];?></td>
                                        <td><?php echo $result['p2_dacharges'];?></td>
                                        <td><?php echo $result['p2_lccharges'];?></td>
                                        <td><?php echo $result['p2_cccharges'];?></td> 
                                        <td><?php echo $result['p2_ticketamount'];?></td>                                        
                                        </tr>
                                        <?php } ?>
                                        <?php  if (!empty($result['p3_citytype'])){?>
                                        <tr>
                                        <td><?php echo $result['p3_citytype'];?></td>     
                                        <td><?php echo $result['p3_startdate'];?></td>
                                        <td><?php echo $result['p3_fromstation'];?></td>
                                        <td><?php echo $result['p3_enddate'];?></td>
                                        <td><?php echo $result['p3_tostation'];?></td>                                        
                                        <td><?php echo $result['p3_km'];?>&nbsp;km</td>
                                        <td ><?php echo $result['p3_totaldays'];?></td>
                                        <td ><?php echo $result['p3_darate'];?></td>
                                        <td><?php echo $result['p3_dacharges'];?></td>
                                        <td><?php echo $result['p3_lccharges'];?></td>
                                        <td><?php echo $result['p3_cccharges'];?></td> 
                                        <td><?php echo $result['p3_ticketamount'];?></td>                                        
                                        </tr>
                                        <?php } ?>
                                        <?php  if (!empty($result['p4_citytype'])){?>
                                        <tr>
                                        <td><?php echo $result['p4_citytype'];?></td>     
                                        <td><?php echo $result['p4_startdate'];?></td>
                                        <td><?php echo $result['p4_fromstation'];?></td>
                                        <td><?php echo $result['p4_enddate'];?></td>
                                        <td><?php echo $result['p4_tostation'];?></td>                                        
                                        <td><?php echo $result['p4_km'];?>&nbsp;km</td>
                                        <td ><?php echo $result['p4_totaldays'];?></td>
                                        <td ><?php echo $result['p4_darate'];?></td>
                                        <td><?php echo $result['p4_dacharges'];?></td>
                                        <td><?php echo $result['p4_lccharges'];?></td>
                                        <td><?php echo $result['p4_cccharges'];?></td> 
                                        <td><?php echo $result['p4_ticketamount'];?></td>                                        
                                        </tr>
                                        <?php } ?>
                                   </tbody>                         
                                 </table><br>

                                <strong><p style="font-size:20px;text-decoration: underline;">Application Status:</p></strong>                               
                                   <table class="table table-bordered table-striped" >
                                   <thead>
                                        <tr>
                                        <th scope="col">Total Amount</th>
                                        <th scope="col">User Remark</th>
                                        <th scope="col">Application Date</th>
                                        <th scope="col">Manager Approval</th>
                                        <th scope="col">Manager Remark</th>
                                        <th scope="col">Admin Approval</th>
                                        <th scope="col">Admin Remark</th>                                        
                                        <th scope="col">Final Approve/Reject Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td >Rs.<?php echo $result['totalamount'];?></td></td>
                                        <td><?php echo $result['remark'];?></td>
                                        <td><?php echo $result['application_date'];?></td>
                                        <td id="ma"><?php echo $result['manager_approval'];
                                         if($result['manager_approval']=='Approved')
                                         {
                                            echo '<style>
                                                      #ma{color:green;font-weight:bold;}
                                                 </style>';
                                         }
                                         if($result['manager_approval']=='Rejected')
                                         {
                                             echo '<style>
                                                       #ma{color:red;font-weight:bold;}
                                                 </style>';
                                         }
                                         
                                        ?></td>
                                        <td><?php echo $result['m_remark'];?></td>
                                         <td id="aa"><?php echo $result['admin_approval'];
                                         if($result['admin_approval']=='Approved')
                                         {
                                            echo '<style>
                                                      #aa{color:green;font-weight:bold;}
                                                 </style>';
                                         }
                                         if($result['admin_approval']=='Rejected')
                                         {
                                             echo '<style>
                                                       #aa{color:red;font-weight:bold;}
                                                 </style>';
                                         }                                        
                                         
                                         ?></td>
                                        <td><?php echo $result['approval_date'];?></td>
                                        
                                        <td><?php echo $result['a_remark'];?></td>

                                        
                                        </tr>
                                   </tbody>

                                   </table><br>
                                   <br>                   
<table>
   
<tr>
                               
                             
                               <?php $ret=mysqli_query($con,"SELECT document_name FROM travel_data WHERE tid='$userid'");
                               while($row=mysqli_fetch_array($ret))
                               {if($row['document_name']==null) {?>   
                               <tr>
                                     <p style="color:red">1. *First Click on Print Button for Printing TA Bill</p>
                                     <p style="color:red">2. *Then Upload Sanctioned TA Bill and Click on Submit</p>
                             </tr>
                               <a class="btn btn-primary" href="manage_user.php" name="back" id="btn" >Back</a>&nbsp;
                               <a href="edit.php?uid=<?php echo $result['tid'];?>" class="btn btn-warning" >Edit TA Bill</a>&nbsp;  
                               <a href="print_pdf.php?uid=<?php echo $result['tid'];?>" type="button" target="_blank" class="btn btn-info">Print</a> &nbsp;
                               <form method="post" action="#" enctype="multipart/form-data">
                               <input  type="file" id="fileToUpload" name="fileToUpload"  class="btn btn-success" style="font-size:small;" required/>
                               <label for="img">Upload Approved TA Bill here</label> &nbsp;&nbsp;
                               <button class="btn btn-primary" name="submit" id="btn" >Submit</button>
                               </form>
                                   
                               <?php } else { ?>
                               
                               <a class="btn btn-primary" href="manage_user.php" name="back" id="btn">Back</a>
                               <?php } } ?>
                             
                             
                             </tr>                     
</table>                
                               
</div>
                               
                            
                            
                           
                            </div>
                        </div>

                        
<?php 
} 
?>
                    


                    </div>
                </main>
                
            </div>
        </div>
      
        

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
