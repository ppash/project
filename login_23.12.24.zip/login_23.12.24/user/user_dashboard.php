<html>
<body>
<script type="text/javascript" src="condition1.js"></script>
<script type="text/javascript" src="condition2.js"></script>
<script type="text/javascript" src="condition3.js"></script>
<script type="text/javascript" src="condition4.js"></script>
<link rel="icon" href="fevicon.png" />

<?php
//include auth_session.php file on all user panel pages
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');

$username = $_SESSION['username'];

if (isset($_POST['submit'])) {

  //-------Common variables declaration---

  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $branch = $_POST['branch'];
  $designation = $_POST['designation'];
  $passing_officer= $_POST['passing_officer'];
  $totalamount = $_POST['totalamount'];
  $remark = $_POST['remark'];

  //-------Part 1 variables declaration--- 
  
  $city1 = $_POST['city1'];
  $fromstation1 = $_POST['fromstation1'];
  $tostation1 = $_POST['tostation1'];
  $kmoftravel1 = $_POST['kmoftravel1'];
  $tod1 = $_POST['tod1'];
  $toa1 = $_POST['toa1'];
  $daysoftravel1 = $_POST['daysoftravel1'];
  
  $daoptradio1 = $_POST['daoptradio1'];
  $da45 = $_POST['da45'];
  $da5 = $_POST['da5'];
  $da6 = $_POST['da6'];
  $lcoptradio1 = $_POST['lcoptradio1'];
  $lc45 = $_POST['lc45'];
  $lc5 = $_POST['lc5'];
  $lc6= $_POST['lc6'];
  $ccoptradio1 = $_POST['ccoptradio1'];
  $cc4 = $_POST['cc4'];
  $cc5 = $_POST['cc5'];
  $cc6 = $_POST['cc6'];
  $ticketoptradio1 = $_POST['ticketoptradio1'];
  $tt4 = $_POST['tt4'];
  $tt5 = $_POST['tt5'];

//-------Part 2 variables declaration---

  
$city2 = $_POST['city2'];
$fromstation2 = $_POST['fromstation2'];
$tostation2 = $_POST['tostation2'];
$kmoftravel2 = $_POST['kmoftravel2'];
$tod2 = $_POST['tod2'];
$toa2 = $_POST['toa2'];
$daysoftravel2 = $_POST['daysoftravel2'];

$daoptradio2 = $_POST['daoptradio2'];
$da451 = $_POST['da451'];
$da51 = $_POST['da51'];
$da61 = $_POST['da61'];
$lcoptradio2 = $_POST['lcoptradio2'];
$lc451 = $_POST['lc451'];
$lc51 = $_POST['lc51'];
$lc61 = $_POST['lc61'];
$ccoptradio2 = $_POST['ccoptradio2'];
$cc41 = $_POST['cc41'];
$cc51 = $_POST['cc51'];
$cc61 = $_POST['cc61'];
$ticketoptradio2 = $_POST['ticketoptradio2'];
$tt41 = $_POST['tt41'];
$tt51 = $_POST['tt51'];

//-------Part 3 variables declaration---

  
$city3 = $_POST['city3'];
$fromstation3 = $_POST['fromstation3'];
$tostation3 = $_POST['tostation3'];
$kmoftravel3 = $_POST['kmoftravel3'];
$tod3 = $_POST['tod3'];
$toa3 = $_POST['toa3'];
$daysoftravel3 = $_POST['daysoftravel3'];

$daoptradio3 = $_POST['daoptradio3'];
$da452 = $_POST['da452'];
$da52 = $_POST['da52'];
$da62 = $_POST['da62'];
$lcoptradio3 = $_POST['lcoptradio3'];
$lc452 = $_POST['lc452'];
$lc52 = $_POST['lc52'];
$lc62 = $_POST['lc62'];
$ccoptradio3 = $_POST['ccoptradio3'];
$cc42 = $_POST['cc42'];
$cc52 = $_POST['cc52'];
$cc62 = $_POST['cc62'];
$ticketoptradio3 = $_POST['ticketoptradio3'];
$tt42 = $_POST['tt42'];
$tt52 = $_POST['tt52'];

//-------Part 4 variables declaration---

  
$city4 = $_POST['city4'];
$fromstation4 = $_POST['fromstation4'];
$tostation4 = $_POST['tostation4'];
$kmoftravel4 = $_POST['kmoftravel4'];
$tod4 = $_POST['tod4'];
$toa4 = $_POST['toa4'];
$daysoftravel4 = $_POST['daysoftravel4'];

$daoptradio4 = $_POST['daoptradio4'];
$da453 = $_POST['da453'];
$da53 = $_POST['da53'];
$da63 = $_POST['da63'];
$lcoptradio4 = $_POST['lcoptradio4'];
$lc453 = $_POST['lc453'];
$lc53 = $_POST['lc53'];
$lc63 = $_POST['lc63'];
$ccoptradio4 = $_POST['ccoptradio4'];
$cc43 = $_POST['cc43'];
$cc53 = $_POST['cc53'];
$cc63 = $_POST['cc63'];
$ticketoptradio4 = $_POST['ticketoptradio4'];
$tt43 = $_POST['tt43'];
$tt53 = $_POST['tt53'];
$p1_lcradio = $_POST['lcoptradio1'];
//--------------------------------------------------------------------------------------------------------------------

 
  
  // $application_date=now();
  // $fileUpload = $_POST['fileUpload'];

  // $fnam2 = $_FILES['fileUpload']['name']; //Ticket bills is fileToUpload
  //echo print_r($_POST);
  //Ticket File uploads
  if ($p1_ticketradio == 'Yes') {
    $my_folder = "usertickets/";
    $uploadOk = true;
    $FileType = pathinfo($my_folder . $_FILES['fileUpload']['name'], PATHINFO_EXTENSION);
    // Check if file already exists
    if (file_exists($my_folder . $_FILES['fileToUpload']['name'])) {
      echo '<script>alert("SAME FILE NAME ALREADY EXIST!. KINDLY CHANGE FILE NAME & FILL FORM AGAIN.")</script>';
      $uploadOk = false;
      // header("Refresh:0;url=user_dashboard.php");
      exit();
    } else if ($uploadOk !== false) {
      move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $my_folder . $_FILES['fileToUpload']['name']);
      $fnam1 = $_FILES['fileToUpload']['name'];
      echo '<script>Received file</script>';

      // mysqli_query($con, $query);
    }
  }

  // Lodging Bills Uploads
if ($p1_lcradio == 'Yes') {
  $my_folder = "userlodgingbills/";
  $uploadOk = false;

  // Ensure the directory exists and has the correct permissions
  if (!is_dir($my_folder)) {
      mkdir($my_folder, 0755, true);
  }

  // Check if file is uploaded
  if (isset($_FILES['fileUpload']) && $_FILES['fileUpload']['error'] == 0) {
      $original_name = basename($_FILES['fileUpload']['name']);
      $fileType = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
      $unique_name = time() . "_" . $original_name; // Unique name with timestamp
      $target_file = $my_folder . $unique_name;

      // Validate file type
      $allowedTypes = ['jpg', 'jpeg', 'png', 'pdf'];
      if (!in_array($fileType, $allowedTypes)) {
          echo '<script>alert("INVALID FILE TYPE! ONLY JPG, JPEG, PNG, AND PDF ALLOWED.")</script>';
          exit();
      }

      // Check file size (5MB limit)
      if ($_FILES['fileUpload']['size'] > 5000000) { // 5MB
          echo '<script>alert("FILE SIZE EXCEEDS THE LIMIT! MAXIMUM ALLOWED SIZE IS 5MB.")</script>';
          exit();
      }

      // Move the file and insert into database
      if (move_uploaded_file($_FILES['fileUpload']['tmp_name'], $target_file)) {
          $fnam2 = $unique_name; // Use the unique file name
          $uploadOk = true;

          // Insert into database
          // $query = "INSERT INTO travel_data (lodging_bills) VALUES (?)";
          $stmt = mysqli_prepare($con, $query);
          mysqli_stmt_bind_param($stmt, "s", $fnam2);
          mysqli_stmt_execute($stmt);

          echo '<script>alert("File Uploaded Successfully!");</script>';
      } else {
          echo '<script>alert("FAILED TO UPLOAD FILE. CHECK PERMISSIONS.");</script>';
      }
  } else {
      echo '<script>alert("NO FILE SELECTED OR UPLOAD ERROR.");</script>';
  }
  // Redirect or reload only if upload was successful
  if ($uploadOk) {
      echo '<script>setTimeout(function(){ window.location.href = "user_dashboard.php"; }, 2000);</script>';
  }
}



  $query = "insert into travel_data(
  username,first_name,last_name,designation,branch,passing_officer,
  p1_citytype,p1_fromstation,p1_tostation,p1_km,p1_startdate,p1_enddate,p1_totaldays,p1_daradio,p1_darate,p1_dadays,p1_dacharges,p1_lcradio,p1_lcrate,p1_lcdays,p1_lccharges,p1_ccradio,p1_ccrate,p1_ccdays,p1_cccharges,p1_ticketradio,p1_ticketcount,p1_ticketamount,
  p2_citytype,p2_fromstation,p2_tostation,p2_km,p2_startdate,p2_enddate,p2_totaldays,p2_daradio,p2_darate,p2_dadays,p2_dacharges,p2_lcradio,p2_lcrate,p2_lcdays,p2_lccharges,p2_ccradio,p2_ccrate,p2_ccdays,p2_cccharges,p2_ticketradio,p2_ticketcount,p2_ticketamount,
  p3_citytype,p3_fromstation,p3_tostation,p3_km,p3_startdate,p3_enddate,p3_totaldays,p3_daradio,p3_darate,p3_dadays,p3_dacharges,p3_lcradio,p3_lcrate,p3_lcdays,p3_lccharges,p3_ccradio,p3_ccrate,p3_ccdays,p3_cccharges,p3_ticketradio,p3_ticketcount,p3_ticketamount,
  p4_citytype,p4_fromstation,p4_tostation,p4_km,p4_startdate,p4_enddate,p4_totaldays,p4_daradio,p4_darate,p4_dadays,p4_dacharges,p4_lcradio,p4_lcrate,p4_lcdays,p4_lccharges,p4_ccradio,p4_ccrate,p4_ccdays,p4_cccharges,p4_ticketradio,p4_ticketcount,p4_ticketamount,
  lodging_bills,tickets_document,totalamount,remark,manager_approval,application_date)

  values(
  '$username','$fname','$lname','$designation','$branch','$passing_officer',
  '$city1','$fromstation1','$tostation1','$kmoftravel1','$tod1','$toa1','$daysoftravel1','$daoptradio1','$da45','$da5','$da6','$lcoptradio1','$lc45','$lc5','$lc6','$ccoptradio1','$cc4','$cc5','$cc6','$ticketoptradio1','$tt4','$tt5',
  '$city2','$fromstation2','$tostation2','$kmoftravel2','$tod2','$toa2','$daysoftravel2','$daoptradio2','$da451','$da51','$da61','$lcoptradio2','$lc451','$lc51','$lc61','$ccoptradio2','$cc41','$cc51','$cc61','$ticketoptradio2','$tt41','$tt51',  
  '$city3','$fromstation3','$tostation3','$kmoftravel3','$tod3','$toa3','$daysoftravel3','$daoptradio3','$da452','$da52','$da62','$lcoptradio3','$lc452','$lc52','$lc62','$ccoptradio3','$cc42','$cc52','$cc62','$ticketoptradio3','$tt42','$tt52',  
  '$city4','$fromstation4','$tostation4','$kmoftravel4','$tod4','$toa4','$daysoftravel4','$daoptradio4','$da453','$da53','$da63','$lcoptradio4','$lc453','$lc53','$lc63','$ccoptradio4','$cc43','$cc53','$cc63','$ticketoptradio4','$tt43','$tt53',
  '$fnam2','$fnam1','$totalamount','$remark','In Process',now())";
  
  if (mysqli_query($con, $query)) {
    echo '<script>alert("TA Bill Submitted");</script>';
    header("Location:manage_user.php");
  } else {
    echo "Error: " . $query . "<br>" . mysqli_error($con);
  }



  // $result2=mysqli_query($con,"update travel_data set lodging_bills='$fnam2' ");

  // header("Location:manage_user.php");
}


?>

<div class="container-fluid" style="padding:0 !important">
  <div class="form">
    <form method="POST" action="#" enctype="multipart/form-data" style="background:linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),url('aucb_wm.png') no-repeat;background-position: center;background-size:55%;">
      <div class="row">
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">First Name</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fname" placeholder="First Name" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Last Name</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="lname" placeholder="Last Name" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="branch" class="form-label">Select your branch</label>
          <select class="form-select" id="branch" aria-label="First Name" name='branch' required>
            <option value="">Select Branch</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From branches");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['br_id'] . " " . $row['br_name'] . "'>" . $row['br_id'] . " " . $row['br_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        <div class="col">
          <label for="desig" class="form-label">Designation</label>
          <select class="form-select" id="desig" aria-label="First Name" name="designation" onChange="myFunction1();myFunction2();myFunction3();myFunction4()" required>
            <option value="$designation">Select your designation</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From designation");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['designation_name'] . "'>" . $row['designation_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        
      </div>
      <hr>
      <div class="row">
        <h6 class="text-left">First Part of Journey</h6>
      </div>
        <div class="row">
       <div class="col">
          <label for="city1" class="form-label">Dest. City Type</label>
          <select class="form-select" aria-label="First Name" id="city1" name='city1' onChange="myFunction1()" required>
            <option value="">Select City</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From city");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['city_name'] . "'>" . $row['city_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">From Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fromstation1" placeholder="From Station" aria-label="Last name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">To Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="tostation1" placeholder="To Station" aria-label="Last name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total KM</label>
          <input type="number" class="form-control" name="kmoftravel1" placeholder="Total Kilo-Meters of Travel" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Start Date</label>
          <input type="datetime-local" class="form-control" id="tod1" name="tod1" placeholder="Time Of Diparture" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">End Date</label>
          <input type="datetime-local" class="form-control" id="toa1" name="toa1" placeholder="Time Of Arrival" aria-label="Last name" onChange="p1_datediff()" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total Days</label>
          <input type="number" class="form-control" id="daysoftravel1" name="daysoftravel1" placeholder="Total Days of Travel" aria-label="Last name" required>
        </div>
      </div>


      <div class="row">
        <div class="col-3">
          <p>Do you want to fill DA Charges?</p>
          <input type="radio" class="form-check-input" id="daradio1" name="daoptradio1" value="Yes" onclick="p1_davisible();p1_damultiply();" required> Yes
          <label class="form-check-label" for="daradio1"> </label>
          <input type="radio" class="form-check-input" id="daradio1" name="daoptradio1" value="No" onclick="p1_dahide();"> No
          <label class="form-check-label" for="daradio1"></label>
        </div>
        <div class="col" id="dashow1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Rate Per DAY:</label>
          <input readonly min="0" type="number" class="form-control" id="da45" name="da45" placeholder="Amount" aria-label="Last name" onChange="p1_damultiply()">
        </div>
        <div class="col" id="dashow2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" min="0" class="form-control" id="da5" name="da5" placeholder="Days" aria-label="Last name" onChange="p1_damultiply()">
        </div>
        <div class="col" id="dashow3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Charges:</label>
          <input readonly type="number" class="form-control" id="da6" name="da6" placeholder="Total Amount" aria-label="Last name">
        </div>
      </div>

 

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Lodging Charges?</p>
          <input type="radio" class="form-check-input" id="lcradio1" name="lcoptradio1" value="Yes" onclick="p1_lcvisible();p1_lcmultiply();" required> Yes
          <label class="form-check-label" for="lcradio1"> </label>
          <input type="radio" class="form-check-input" id="lcradio1" name="lcoptradio1" value="No" onclick="p1_lchide();"> No
          <label class="form-check-label" for="lcradio1"></label>
        </div>
        <div class="col" id="lcshow1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Rate Per DAY:</label>
          <input readonly type="number" class="form-control" id="lc45" name="lc45" placeholder="Amount" aria-label="Last name" onChange="p1_lcmultiply()">
        </div>
        <div class="col" id="lcshow2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="lc5" name="lc5" placeholder="Days" aria-label="Last name" onChange="p1_lcmultiply()">
        </div>
        <div class="col" id="lcshow3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Charges:</label>
          <input readonly type="number" class="form-control" id="lc6" name="lc6" placeholder="Total Amount" aria-label="Last name">
        </div>
        
      </div>
      
      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Conveyance charges?</p>
          <input type="radio" class="form-check-input" id="ccradio1" name="ccoptradio1" value="Yes" onclick="p1_ccvisible();p1_ccmultiply()" required> Yes
          <label class="form-check-label" for="ccradio1"> </label>
          <input type="radio" class="form-check-input" id="ccradio1" name="ccoptradio1" value="No" onclick="p1_cchide();"> No
          <label class="form-check-label" for="ccradio1"></label>
        </div>
        <div class="col" id="ccshow1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conv. Rate(Auto/Rikshaw fare) Per DAY:</label>
          <input type="number" class="form-control" id="cc4" name="cc4" placeholder="Amount" aria-label="Last name" onChange="p1_ccmultiply()">
        </div>
        <div class="col" id="ccshow2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="cc5" name="cc5" placeholder="Days" aria-label="Last name" onChange="p1_ccmultiply()">
        </div>
        <div class="col" id="ccshow3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conveyance Charges:</label>
          <input readonly type="number" class="form-control" id="cc6" name="cc6" placeholder="Total Amount" aria-label="Last name">
        </div>

      </div>

    

      <div class="row">     

        <div class="col-3">
          <p>Do you want to fill Railway/Bus ticket charges?</p>
          <input type="radio" class="form-check-input" id="ticketradio1" name="ticketoptradio1" value="Yes" onclick="p1_ticketvisible();" required> Yes
          <label class="form-check-label" for="ticketradio1"> </label>
          <input type="radio" class="form-check-input" id="ticketradio1" name="ticketoptradio1" value="No" onclick="p1_tickethide();"> No
          <label class="form-check-label" for="ticketradio1"></label>
        </div>


        <div class="col" id="ttshow1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total no of tickets</label>
          <input type="number" class="form-control" id="tt4" name="tt4" placeholder="Total no of tickets" aria-label="Last name">
        </div>

        <div class="col" id="ttshow2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total ticket amount</label>
          <input type="number" class="form-control" id="tt5" name="tt5" placeholder="Total Amount" aria-label="Last name">
        </div>

       

      </div>
     
      <hr>

     <div class="row">
        <h6 class="text-left">Second Part of Journey</h6>
      </div>     
           

      <div class="row">
      <div class="col">
          <label for="city2" class="form-label">Dest. City Type</label>
          <select class="form-select" aria-label="First Name" id="city2" name='city2' onChange="myFunction2()" >
            <option value="">Select City</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From city");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['city_name'] . "'>" . $row['city_name'] . "</option>";
            }
            ?>
          </select>
        </div>    
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">From Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fromstation2" placeholder="From Station" aria-label="Last name">
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">To Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="tostation2" placeholder="To Station" aria-label="Last name">
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total KM</label>
          <input type="number" class="form-control" name="kmoftravel2" placeholder="Total Kilo-Meters of Travel" aria-label="First name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Start Date</label>
          <input type="datetime-local" class="form-control" id="tod2" name="tod2" placeholder="Time Of Diparture" aria-label="First name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">End Date</label>
          <input type="datetime-local" class="form-control" id="toa2" name="toa2" placeholder="Time Of Arrival" aria-label="Last name" onChange="p2_datediff()" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total Days</label>
          <input type="number" class="form-control" id="daysoftravel2" name="daysoftravel2" placeholder="Total Days of Travel" aria-label="Last name" >
        </div>
      </div>


      <div class="row">
        <div class="col-3">
          <p>Do you want to fill DA Charges?</p>
          <input type="radio" class="form-check-input" id="daradio2" name="daoptradio2" value="Yes" onclick="p2_davisible();p2_damultiply();"> Yes
          <label class="form-check-label" for="daradio2"> </label>
          <input type="radio" class="form-check-input" id="daradio2" name="daoptradio2" value="No" onclick="p2_dahide();"> No
          <label class="form-check-label" for="daradio2"></label>
        </div>
        <div class="col" id="dashow4" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Rate Per DAY:</label>
          <input readonly min="0" type="number" class="form-control" id="da451" name="da451" placeholder="Amount" aria-label="Last name" onChange="p2_damultiply()">
        </div>
        <div class="col" id="dashow5" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" min="0" class="form-control" id="da51" name="da51" placeholder="Days" aria-label="Last name" onChange="p2_damultiply()">
        </div>
        <div class="col" id="dashow6" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Charges:</label>
          <input readonly type="number" class="form-control" id="da61" name="da61" placeholder="Total Amount" aria-label="Last name">
        </div>
      </div>



      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Lodging Charges?</p>
          <input type="radio" class="form-check-input" id="lcradio2" name="lcoptradio2" value="Yes" onclick="p2_lcvisible();p2_lcmultiply();" > Yes
          <label class="form-check-label" for="lcradio2"> </label>
          <input type="radio" class="form-check-input" id="lcradio2" name="lcoptradio2" value="No" onclick="p2_lchide();"> No
          <label class="form-check-label" for="lcradio2"></label>
        </div>
        <div class="col" id="lcshow4" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Rate Per DAY:</label>
          <input readonly type="number" class="form-control" id="lc451" name="lc451" placeholder="Amount" aria-label="Last name" onChange="p2_lcmultiply()">
        </div>
        <div class="col" id="lcshow5" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="lc51" name="lc51" placeholder="Days" aria-label="Last name" onChange="p2_lcmultiply()">
        </div>
        <div class="col" id="lcshow6" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Charges:</label>
          <input readonly type="number" class="form-control" id="lc61" name="lc61" placeholder="Total Amount" aria-label="Last name">
        </div>
        
      </div>



      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Conveyance charges?</p>
          <input type="radio" class="form-check-input" id="ccradio2" name="ccoptradio2" value="Yes" onclick="p2_ccvisible();p2_ccmultiply()" > Yes
          <label class="form-check-label" for="ccradio2"> </label>
          <input type="radio" class="form-check-input" id="ccradio2" name="ccoptradio2" value="No" onclick="p2_cchide();"> No
          <label class="form-check-label" for="ccradio2"></label>
        </div>
        <div class="col" id="ccshow4" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conv. Rate(Auto/Rikshaw fare) Per DAY:</label>
          <input type="number" class="form-control" id="cc41" name="cc41" placeholder="Amount" aria-label="Last name" onChange="p2_ccmultiply()">
        </div>
        <div class="col" id="ccshow5" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="cc51" name="cc51" placeholder="Days" aria-label="Last name" onChange="p2_ccmultiply()">
        </div>
        <div class="col" id="ccshow6" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conveyance Charges:</label>
          <input readonly type="number" class="form-control" id="cc61" name="cc61" placeholder="Total Amount" aria-label="Last name">
        </div>
      </div>


      <div class="row">
     

        <div class="col-3">
          <p>Do you want to fill Railway/Bus ticket charges?</p>
          <input type="radio" class="form-check-input" id="ticketradio2" name="ticketoptradio2" value="Yes" onclick="p2_ticketvisible();" > Yes
          <label class="form-check-label" for="ticketradio2"> </label>
          <input type="radio" class="form-check-input" id="ticketradio2" name="ticketoptradio2" value="No" onclick="p2_tickethide();"> No
          <label class="form-check-label" for="ticketradio2"></label>
        </div>


        <div class="col" id="ttshow3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total no of tickets</label>
          <input type="number" class="form-control" id="tt41" name="tt41" placeholder="Total no of tickets" aria-label="Last name">
        </div>

        <div class="col" id="ttshow4" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total ticket amount</label>
          <input type="number" class="form-control" id="tt51" name="tt51" placeholder="Total Amount" aria-label="Last name">
        </div>

        

      </div>

      
      
      <hr>
      <div class="row">
        <h6 class="text-left">Third Part of Journey</h6>
      </div>
        <div class="row">
       <div class="col">
          <label for="city3" class="form-label">Dest. City Type</label>
          <select class="form-select" aria-label="First Name" id="city3" name='city3' onChange="myFunction3()" >
            <option value="">Select City</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From city");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['city_name'] . "'>" . $row['city_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">From Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fromstation3" placeholder="From Station" aria-label="Last name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">To Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="tostation3" placeholder="To Station" aria-label="Last name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total KM</label>
          <input type="number" class="form-control" name="kmoftravel3" placeholder="Total Kilo-Meters of Travel" aria-label="First name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Start Date</label>
          <input type="datetime-local" class="form-control" id="tod3" name="tod3" placeholder="Time Of Diparture" aria-label="First name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">End Date</label>
          <input type="datetime-local" class="form-control" id="toa3" name="toa3" placeholder="Time Of Arrival" aria-label="Last name" onChange="p3_datediff()" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total Days</label>
          <input type="number" class="form-control" id="daysoftravel3" name="daysoftravel3" placeholder="Total Days of Travel" aria-label="Last name" >
        </div>
      </div>


      <div class="row">
        <div class="col-3">
          <p>Do you want to fill DA Charges?</p>
          <input type="radio" class="form-check-input" id="daradio3" name="daoptradio3" value="Yes" onclick="p3_davisible();multiply();" > Yes
          <label class="form-check-label" for="daradio3"> </label>
          <input type="radio" class="form-check-input" id="daradio3" name="daoptradio3" value="No" onclick="p3_dahide();"> No
          <label class="form-check-label" for="daradio3"></label>
        </div>
        <div class="col" id="dashow7" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Rate Per DAY:</label>
          <input readonly min="0" type="number" class="form-control" id="da452" name="da452" placeholder="Amount" aria-label="Last name" onChange="p3_damultiply()">
        </div>
        <div class="col" id="dashow8" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" min="0" class="form-control" id="da52" name="da52" placeholder="Days" aria-label="Last name" onChange="p3_damultiply()">
        </div>
        <div class="col" id="dashow9" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Charges:</label>
          <input readonly type="number" class="form-control" id="da62" name="da62" placeholder="Total Amount" aria-label="Last name">
        </div>
      </div>



      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Lodging Charges?</p>
          <input type="radio" class="form-check-input" id="lcradio3" name="lcoptradio3" value="Yes" onclick="p3_lcvisible();multiply();"> Yes
          <label class="form-check-label" for="lcradio3"> </label>
          <input type="radio" class="form-check-input" id="lcradio3" name="lcoptradio3" value="No" onclick="p3_lchide();"> No
          <label class="form-check-label" for="lcradio3"></label>
        </div>
        <div class="col" id="lcshow7" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Rate Per DAY:</label>
          <input readonly type="number" class="form-control" id="lc452" name="lc452" placeholder="Amount" aria-label="Last name" onChange="p3_lcmultiply()">
        </div>
        <div class="col" id="lcshow8" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="lc52" name="lc52" placeholder="Days" aria-label="Last name" onChange="p3_lcmultiply()">
        </div>
        <div class="col" id="lcshow9" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Charges:</label>
          <input readonly type="number" class="form-control" id="lc62" name="lc62" placeholder="Total Amount" aria-label="Last name">
        </div>
        
      </div>

  

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Conveyance charges?</p>
          <input type="radio" class="form-check-input" id="ccradio3" name="ccoptradio3" value="Yes" onclick="p3_ccvisible();p3_ccmultiply()" > Yes
          <label class="form-check-label" for="ccradio3"> </label>
          <input type="radio" class="form-check-input" id="ccradio3" name="ccoptradio3" value="No" onclick="p3_cchide();"> No
          <label class="form-check-label" for="ccradio3"></label>
        </div>
        <div class="col" id="ccshow7" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conv. Rate(Auto/Rikshaw fare) Per DAY:</label>
          <input type="number" class="form-control" id="cc42" name="cc42" placeholder="Amount" aria-label="Last name" onChange="p3_ccmultiply()">
        </div>
        <div class="col" id="ccshow8" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="cc52" name="cc52" placeholder="Days" aria-label="Last name" onChange="p3_ccmultiply()">
        </div>
        <div class="col" id="ccshow9" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conveyance Charges:</label>
          <input readonly type="number" class="form-control" id="cc62" name="cc62" placeholder="Total Amount" aria-label="Last name">
        </div>

      </div>



      <div class="row">     

        <div class="col-3">
          <p>Do you want to fill Railway/Bus ticket charges?</p>
          <input type="radio" class="form-check-input" id="ticketradio3" name="ticketoptradio3" value="Yes" onclick="p3_ticketvisible();" > Yes
          <label class="form-check-label" for="ticketradio3"> </label>
          <input type="radio" class="form-check-input" id="ticketradio3" name="ticketoptradio3" value="No" onclick="p3_tickethide();"> No
          <label class="form-check-label" for="ticketradio3"></label>
        </div>


        <div class="col" id="ttshow5" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total no of tickets</label>
          <input type="number" class="form-control" id="tt42" name="tt42" placeholder="Total no of tickets" aria-label="Last name">
        </div>

        <div class="col" id="ttshow6" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total ticket amount</label>
          <input type="number" class="form-control" id="tt52" name="tt52" placeholder="Total Amount" aria-label="Last name">
        </div>

       

      </div>

      <hr>
      <div class="row">
        <h6 class="text-left">Fourth Part of Journey</h6>
      </div>
        <div class="row">
       <div class="col">
          <label for="city4" class="form-label">Dest. City Type</label>
          <select class="form-select" aria-label="First Name" id="city4" name='city4' onChange="myFunction4()" >
            <option value="">Select City</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From city");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['city_name'] . "'>" . $row['city_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">From Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fromstation4" placeholder="From Station" aria-label="Last name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">To Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="tostation4" placeholder="To Station" aria-label="Last name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total KM</label>
          <input type="number" class="form-control" name="kmoftravel4" placeholder="Total Kilo-Meters of Travel" aria-label="First name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Start Date</label>
          <input type="datetime-local" class="form-control" id="tod4" name="tod4" placeholder="Time Of Diparture" aria-label="First name" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">End Date</label>
          <input type="datetime-local" class="form-control" id="toa4" name="toa4" placeholder="Time Of Arrival" aria-label="Last name" onChange="p4_datediff()" >
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total Days</label>
          <input type="number" class="form-control" id="daysoftravel4" name="daysoftravel4" placeholder="Total Days of Travel" aria-label="Last name" >
        </div>
      </div>
 

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill DA Charges?</p>
          <input type="radio" class="form-check-input" id="daradio4" name="daoptradio4" value="Yes" onclick="p4_davisible();p4_damultiply()"> Yes
          <label class="form-check-label" for="daradio4"> </label>
          <input type="radio" class="form-check-input" id="daradio4" name="daoptradio4" value="No" onclick="p4_dahide();"> No
          <label class="form-check-label" for="daradio4"></label>
        </div>
        <div class="col" id="dashow10" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Rate Per DAY:</label>
          <input readonly min="0" type="number" class="form-control" id="da453" name="da453" placeholder="Amount" aria-label="Last name" onChange="p4_damultiply()">
        </div>
        <div class="col" id="dashow11" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" min="0" class="form-control" id="da53" name="da53" placeholder="Days" aria-label="Last name" onChange="p4_damultiply()">
        </div>
        <div class="col" id="dashow12" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Charges:</label>
          <input readonly type="number" class="form-control" id="da63" name="da63" placeholder="Total Amount" aria-label="Last name">
        </div>
      </div>



      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Lodging Charges?</p>
          <input type="radio" class="form-check-input" id="lcradio4" name="lcoptradio4" value="Yes" onclick="p4_lcvisible();p4_lcmultiply();"> Yes
          <label class="form-check-label" for="lcradio4"> </label>
          <input type="radio" class="form-check-input" id="lcradio4" name="lcoptradio4" value="No" onclick="p4_lchide();"> No
          <label class="form-check-label" for="lcradio4"></label>
        </div>
        <div class="col" id="lcshow10" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Rate Per DAY:</label>
          <input readonly type="number" class="form-control" id="lc453" name="lc453" placeholder="Amount" aria-label="Last name" onChange="p4_lcmultiply()">
        </div>
        <div class="col" id="lcshow11" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="lc53" name="lc53" placeholder="Days" aria-label="Last name" onChange="p4_lcmultiply()">
        </div>
        <div class="col" id="lcshow12" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Charges:</label>
          <input readonly type="number" class="form-control" id="lc63" name="lc63" placeholder="Total Amount" aria-label="Last name">
        </div>
        
      </div>



      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Conveyance charges?</p>
          <input type="radio" class="form-check-input" id="ccradio4" name="ccoptradio4" value="Yes" onclick="p4_ccvisible();p4_ccmultiply()" > Yes
          <label class="form-check-label" for="ccradio4"> </label>
          <input type="radio" class="form-check-input" id="ccradio4" name="ccoptradio4" value="No" onclick="p4_cchide();"> No
          <label class="form-check-label" for="ccradio4"></label>
        </div>
        <div class="col" id="ccshow10" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conv. Rate(Auto/Rikshaw fare) Per DAY:</label>
          <input type="number" class="form-control" id="cc43" name="cc43" placeholder="Amount" aria-label="Last name" onChange="p4_ccmultiply()">
        </div>
        <div class="col" id="ccshow11" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="cc53" name="cc53" placeholder="Days" aria-label="Last name" onChange="p4_ccmultiply()">
        </div>
        <div class="col" id="ccshow12" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conveyance Charges:</label>
          <input readonly type="number" class="form-control" id="cc63" name="cc63" placeholder="Total Amount" aria-label="Last name">
        </div>

      </div>

 

      <div class="row">     

        <div class="col-3">
          <p>Do you want to fill Railway/Bus ticket charges?</p>
          <input type="radio" class="form-check-input" id="ticketradio4" name="ticketoptradio4" value="Yes" > Yes
          <label class="form-check-label" for="ticketradio4"> </label>
          <input type="radio" class="form-check-input" id="ticketradio4" name="ticketoptradio4" value="No" > No
          <label class="form-check-label" for="ticketradio4"></label>
        </div>


        <div class="col" id="ttshow7" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total no of tickets</label>
          <input type="number" class="form-control" id="tt43" name="tt43" placeholder="Total no of tickets" aria-label="Last name">
        </div>

        <div class="col" id="ttshow8" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total ticket amount</label>
          <input type="number" class="form-control" id="tt53" name="tt53" placeholder="Total Amount" aria-label="Last name">
        </div>

       

      </div>

      
      <hr>
          
      <div class="row">

      <div class="col" id="lc7">
          <label for="img">Upload Lodging Bills Here :</label><br>
          <input type="file" id="fileUpload" name="fileUpload" />
        </div>

        <div class="col" id="tt3">
          <label for="img">Upload Tickets Here :</label> <br>
          <input type="file" id="fileToUpload" name="fileToUpload" />
        </div>

        <div class="col-4">
          <label for="exampleFormControlInput1" class="form-label" style="display:block;">Click below button to get total amount: </label>
          <input type="button" value="Calculate Total" onclick="addn()" required />
        </div>

        <div class="col-4">
          <label for="exampleFormControlInput1" class="form-label">Total Amount</label>
          <input readonly type="text" class="form-control" id="totalamount" name="totalamount" placeholder="Total" aria-label="First name" required>
        </div>
        <div class="col-4">
          <label for="exampleFormControlInput1" class="form-label">Remark/Purpose</label>
          <textarea class="form-control" rows="3" style="text-transform: capitalize;" placeholder="Remark (if any)" name="remark" aria-label="Last name" required></textarea>

        </div>
  </div>
  <br> 
      <center>
        <tr>
          <td>
            <button class="btn btn-primary" value="Submit" type="submit" name="submit" id="btn">Save</button>
          </td>

          <td>
            <button class="btn btn-danger" name="reset_form" id="btn_r" onClick="location.reload();">Reset</button>
          </td>
        </tr>
      </center>


			
  </div>
</div>


<!-- Java Script Get Started From here -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
var i=1;
$('#add').click(function(){
i++;
$('#dynamic_field').append('<tr id="row1'+i+'"><td><input type="text" name="skill[]" placeholder="Enter your Skill" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');
});
	
$(document).on('click', '.btn_remove', function(){
var button_id = $(this).attr("id"); 
$('#row1'+button_id+'').remove();
});
});
</script>

<script>
// ----------------------------------p1 function starts here----------------------------------

  function p1_dahide()  {

    document.getElementById("da5").value = null;
    document.getElementById("da6").value = null;
    document.getElementById('dashow1').style.display = 'none';
    document.getElementById('dashow2').style.display = 'none';
    document.getElementById('dashow3').style.display = 'none';
    document.getElementById('da45').required = false;
    document.getElementById("da5").required = false;
    document.getElementById("da6").required = false;

  }

  function p1_davisible() {

    document.getElementById('dashow1').style.display = 'block';
    document.getElementById('dashow2').style.display = 'block';
    document.getElementById('dashow3').style.display = 'block';
    document.getElementById('da45').required = true;
    document.getElementById("da5").required = true;
    document.getElementById("da6").required = true;
    
  }


  function p1_lchide() {
   
    document.getElementById("lc5").value = null;
    document.getElementById("lc6").value = null;
    document.getElementById('lcshow1').style.display = 'none';
    document.getElementById('lcshow2').style.display = 'none';
    document.getElementById('lcshow3').style.display = 'none';   
    document.getElementById("lc5").required = false;
    document.getElementById("lc6").required = false;
    
  }

  function p1_lcvisible() {
    document.getElementById('lcshow1').style.display = 'block';
    document.getElementById('lcshow2').style.display = 'block';
    document.getElementById('lcshow3').style.display = 'block';    
    document.getElementById("lc45").required = true;
    document.getElementById("lc5").required = true;
    document.getElementById("lc6").required = true;
    
  }

  function p1_cchide() {
    document.getElementById("cc4").value = null;
    document.getElementById("cc5").value = null;
    document.getElementById("cc6").value = null;
    document.getElementById('ccshow1').style.display = 'none';
    document.getElementById('ccshow2').style.display = 'none';
    document.getElementById('ccshow3').style.display = 'none';
    document.getElementById("cc4").required = false;
    document.getElementById("cc5").required = false;
    document.getElementById("cc6").required = false;

  }

  function p1_ccvisible() {
    document.getElementById('ccshow1').style.display = 'block';
    document.getElementById('ccshow2').style.display = 'block';
    document.getElementById('ccshow3').style.display = 'block';
    document.getElementById("cc4").required = true;
    document.getElementById("cc5").required = true;
    document.getElementById("cc6").required = true;
  }

  function p1_tickethide() {
    document.getElementById("tt4").value = null;
    document.getElementById("tt5").value = null;
    document.getElementById('ttshow1').style.display = 'none';
    document.getElementById('ttshow2').style.display = 'none';    
    document.getElementById("tt4").required = false;
    document.getElementById("tt5").required = false;
    
  }

  function p1_ticketvisible() {
    document.getElementById('ttshow1').style.display = 'block';
    document.getElementById('ttshow2').style.display = 'block';    
    document.getElementById("tt4").required = true;
    document.getElementById("tt5").required = true;
    
  }


// ----------------------------------p2 function starts here----------------------------------

  function p2_dahide() {

document.getElementById("da51").value = null;
document.getElementById("da61").value = null;
document.getElementById('dashow4').style.display = 'none';
document.getElementById('dashow5').style.display = 'none';
document.getElementById('dashow6').style.display = 'none';
document.getElementById('da451').required = false;
document.getElementById("da51").required = false;
document.getElementById("da61").required = false;

}

function p2_davisible() {

    document.getElementById('dashow4').style.display = 'block';
    document.getElementById('dashow5').style.display = 'block';
    document.getElementById('dashow6').style.display = 'block';
    document.getElementById('da451').required = true;
    document.getElementById("da51").required = true;
    document.getElementById("da61").required = true;
}

  
function p2_lchide() {

 
    document.getElementById("lc51").value = null;
    document.getElementById("lc61").value = null;
    document.getElementById('lcshow4').style.display = 'none';
    document.getElementById('lcshow5').style.display = 'none';
    document.getElementById('lcshow6').style.display = 'none';      
    document.getElementById("lc51").required = false;
    document.getElementById("lc61").required = false;
}

function p2_lcvisible() {

  document.getElementById('lcshow4').style.display = 'block';
    document.getElementById('lcshow5').style.display = 'block';
    document.getElementById('lcshow6').style.display = 'block';
    document.getElementById("lc451").required = true;
    document.getElementById("lc51").required = true;
    document.getElementById("lc61").required = true;
    
}

  
function p2_cchide() {

    document.getElementById("cc41").value = null;
    document.getElementById("cc51").value = null;
    document.getElementById("cc61").value = null;
    document.getElementById('ccshow4').style.display = 'none';
    document.getElementById('ccshow5').style.display = 'none';
    document.getElementById('ccshow6').style.display = 'none';
    document.getElementById("cc41").required = false;
    document.getElementById("cc51").required = false;
    document.getElementById("cc61").required = false;

}

function p2_ccvisible() {

    document.getElementById('ccshow4').style.display = 'block';
    document.getElementById('ccshow5').style.display = 'block';
    document.getElementById('ccshow6').style.display = 'block';
    document.getElementById("cc41").required = true;
    document.getElementById("cc51").required = true;
    document.getElementById("cc61").required = true;

}
 

function p2_tickethide() {

    document.getElementById("tt41").value = null;
    document.getElementById("tt51").value = null;
    document.getElementById('ttshow3').style.display = 'none';
    document.getElementById('ttshow4').style.display = 'none';
    document.getElementById("tt41").required = false;
    document.getElementById("tt51").required = false;


}

  
  function p2_ticketvisible() {

    document.getElementById('ttshow3').style.display = 'block';
    document.getElementById('ttshow4').style.display = 'block'; 
    document.getElementById("tt41").required = true;
    document.getElementById("tt51").required = true;


}
// ----------------------------------p3 function starts here----------------------------------
function p3_dahide()  {

document.getElementById("da52").value = null;
document.getElementById("da62").value = null;
document.getElementById('dashow7').style.display = 'none';
document.getElementById('dashow8').style.display = 'none';
document.getElementById('dashow9').style.display = 'none';
document.getElementById('da452').required = false;
document.getElementById("da52").required = false;
document.getElementById("da62").required = false;

}

function p3_davisible() {

document.getElementById('dashow7').style.display = 'block';
document.getElementById('dashow8').style.display = 'block';
document.getElementById('dashow9').style.display = 'block';
document.getElementById('da452').required = true;
document.getElementById("da52").required = true;
document.getElementById("da62").required = true;

}


function p3_lchide() {

document.getElementById("lc52").value = null;
document.getElementById("lc62").value = null;
document.getElementById('lcshow7').style.display = 'none';
document.getElementById('lcshow8').style.display = 'none';
document.getElementById('lcshow9').style.display = 'none';   
document.getElementById("lc52").required = false;
document.getElementById("lc62").required = false;

}

function p3_lcvisible() {
document.getElementById('lcshow7').style.display = 'block';
document.getElementById('lcshow8').style.display = 'block';
document.getElementById('lcshow9').style.display = 'block';    
document.getElementById("lc452").required = true;
document.getElementById("lc52").required = true;
document.getElementById("lc62").required = true;

}

function p3_cchide() {
document.getElementById("cc42").value = null;
document.getElementById("cc52").value = null;
document.getElementById("cc62").value = null;
document.getElementById('ccshow7').style.display = 'none';
document.getElementById('ccshow8').style.display = 'none';
document.getElementById('ccshow9').style.display = 'none';
document.getElementById("cc42").required = false;
document.getElementById("cc52").required = false;
document.getElementById("cc62").required = false;

}

function p3_ccvisible() {
document.getElementById('ccshow7').style.display = 'block';
document.getElementById('ccshow8').style.display = 'block';
document.getElementById('ccshow9').style.display = 'block';
document.getElementById("cc42").required = true;
document.getElementById("cc52").required = true;
document.getElementById("cc62").required = true;
}

function p3_tickethide() {
document.getElementById("tt42").value = null;
document.getElementById("tt52").value = null;
document.getElementById('ttshow5').style.display = 'none';
document.getElementById('ttshow6').style.display = 'none';    
document.getElementById("tt42").required = false;
document.getElementById("tt52").required = false;

}

function p3_ticketvisible() {
document.getElementById('ttshow5').style.display = 'block';
document.getElementById('ttshow6').style.display = 'block';    
document.getElementById("tt42").required = true;
document.getElementById("tt52").required = true;

}
// ----------------------------------p4 function starts here----------------------------------
function p4_dahide()  {

document.getElementById("da53").value = null;
document.getElementById("da63").value = null;
document.getElementById('dashow10').style.display = 'none';
document.getElementById('dashow11').style.display = 'none';
document.getElementById('dashow12').style.display = 'none';
document.getElementById('da453').required = false;
document.getElementById("da53").required = false;
document.getElementById("da63").required = false;

}

function p4_davisible() {

document.getElementById('dashow10').style.display = 'block';
document.getElementById('dashow11').style.display = 'block';
document.getElementById('dashow12').style.display = 'block';
document.getElementById('da453').required = true;
document.getElementById("da53").required = true;
document.getElementById("da63").required = true;

}


function p4_lchide() {

document.getElementById("lc53").value = null;
document.getElementById("lc63").value = null;
document.getElementById('lcshow10').style.display = 'none';
document.getElementById('lcshow11').style.display = 'none';
document.getElementById('lcshow12').style.display = 'none';   
document.getElementById("lc53").required = false;
document.getElementById("lc63").required = false;

}

function p4_lcvisible() {
document.getElementById('lcshow10').style.display = 'block';
document.getElementById('lcshow11').style.display = 'block';
document.getElementById('lcshow12').style.display = 'block';    
document.getElementById("lc453").required = true;
document.getElementById("lc53").required = true;
document.getElementById("lc63").required = true;

}

function p4_cchide() {
document.getElementById("cc43").value = null;
document.getElementById("cc53").value = null;
document.getElementById("cc63").value = null;
document.getElementById('ccshow10').style.display = 'none';
document.getElementById('ccshow11').style.display = 'none';
document.getElementById('ccshow12').style.display = 'none';
document.getElementById("cc43").required = false;
document.getElementById("cc53").required = false;
document.getElementById("cc63").required = false;

}

function p4_ccvisible() {
document.getElementById('ccshow10').style.display = 'block';
document.getElementById('ccshow11').style.display = 'block';
document.getElementById('ccshow12').style.display = 'block';
document.getElementById("cc43").required = true;
document.getElementById("cc53").required = true;
document.getElementById("cc63").required = true;
}

function p4_tickethide() {
document.getElementById("tt43").value = null;
document.getElementById("tt53").value = null;
document.getElementById('ttshow7').style.display = 'none';
document.getElementById('ttshow8').style.display = 'none';    
document.getElementById("tt43").required = false;
document.getElementById("tt53").required = false;

}

function p4_ticketvisible() {
document.getElementById('ttshow7').style.display = 'block';
document.getElementById('ttshow8').style.display = 'block';    
document.getElementById("tt43").required = true;
document.getElementById("tt53").required = true;

}



  function p1_damultiply(){
    var val1 = document.getElementById('da45').value;
    var val2 = document.getElementById('da5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('da6').value = mul;
  }

  function p1_lcmultiply(){
    var val1 = document.getElementById('lc45').value;
    var val2 = document.getElementById('lc5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('lc6').value = mul;
  }

  function p1_ccmultiply() {
    var val1 = document.getElementById('cc4').value;
    var val2 = document.getElementById('cc5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('cc6').value = mul;
  }
 

  function p2_damultiply(){
    var val1 = document.getElementById('da451').value;
    var val2 = document.getElementById('da51').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('da61').value = mul;
  }

  function p2_lcmultiply(){
    var val1 = document.getElementById('lc451').value;
    var val2 = document.getElementById('lc51').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('lc61').value = mul;
  }

  function p2_ccmultiply() {
    var val1 = document.getElementById('cc41').value;
    var val2 = document.getElementById('cc51').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('cc61').value = mul;
  }
  
  function p3_damultiply(){
    var val1 = document.getElementById('da452').value;
    var val2 = document.getElementById('da52').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('da62').value = mul;
  }

  function p3_lcmultiply(){
    var val1 = document.getElementById('lc452').value;
    var val2 = document.getElementById('lc52').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('lc62').value = mul;
  }

  function p3_ccmultiply() {
    var val1 = document.getElementById('cc42').value;
    var val2 = document.getElementById('cc52').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('cc62').value = mul;
  }

  function p4_damultiply(){
    var val1 = document.getElementById('da453').value;
    var val2 = document.getElementById('da53').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('da63').value = mul;
  }

  function p4_lcmultiply(){
    var val1 = document.getElementById('lc453').value;
    var val2 = document.getElementById('lc53').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('lc63').value = mul;
  }

  function p4_ccmultiply() {
    var val1 = document.getElementById('cc43').value;
    var val2 = document.getElementById('cc53').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('cc63').value = mul;
  }


  function addn() {
    var val1 = document.getElementById('da6').value;
    var val2 = document.getElementById('lc6').value;
    var val3 = document.getElementById('cc6').value;
    var val4 = document.getElementById('tt5').value;
    
    var val5 = document.getElementById('da61').value;
    var val6 = document.getElementById('lc61').value;
    var val7 = document.getElementById('cc61').value;
    var val8 = document.getElementById('tt51').value;

    var val9 = document.getElementById('da62').value;
    var val10 = document.getElementById('lc62').value;
    var val11 = document.getElementById('cc62').value;
    var val12 = document.getElementById('tt52').value;

    var val13 = document.getElementById('da63').value;
    var val14 = document.getElementById('lc63').value;
    var val15 = document.getElementById('cc63').value;
    var val16 = document.getElementById('tt53').value;

    var addn = Number(val1) + Number(val2) + Number(val3) + Number(val4) +
                Number(val5) + Number(val6) + Number(val7) + Number(val8) +
                Number(val9) + Number(val10) + Number(val11) + Number(val12) +
                Number(val13) + Number(val14) + Number(val15) + Number(val16);
    
    document.getElementById('totalamount').value = addn;
  }
</script>



<script>
  
  document.querySelector("#toa1").addEventListener("change", myFunction1);

  function p1_datediff() {

    //value start
    var start = Date.parse($("input#tod1").val()); //get timestamp

    //value end
    var end = Date.parse($("input#toa1").val()); //get timestamp

    totalHours = NaN;

    if (start < end) {
      totalHours = Math.floor((end - start) / 1000 / 60 / 60); //milliseconds: /1000 / 60 / 60

      days = Math.round(totalHours / 24);

    } else {
      alert('The end date and time of the journey should not be less than the start date and time.');
    }
    $("#totalhour").val(totalHours);

    $("#daysoftravel1").val(days);

  }

  
  function p2_datediff() {

//value start
var start = Date.parse($("input#tod2").val()); //get timestamp

//value end
var end = Date.parse($("input#toa2").val()); //get timestamp

totalHours = NaN;

if (start < end) {
  totalHours = Math.floor((end - start) / 1000 / 60 / 60); //milliseconds: /1000 / 60 / 60

  days = Math.round(totalHours / 24);

} else {
  alert('The end date and time of the journey should not be less than the start date and time.');
}
$("#totalhour").val(totalHours);

$("#daysoftravel2").val(days);

}



function p3_datediff() {

//value start
var start = Date.parse($("input#tod3").val()); //get timestamp

//value end
var end = Date.parse($("input#toa3").val()); //get timestamp

totalHours = NaN;

if (start < end) {
  totalHours = Math.floor((end - start) / 1000 / 60 / 60); //milliseconds: /1000 / 60 / 60

  days = Math.round(totalHours / 24);

} else {
  alert('The end date and time of the journey should not be less than the start date and time.');
}
$("#totalhour").val(totalHours);

$("#daysoftravel3").val(days);

}


function p4_datediff(){

//value start
var start = Date.parse($("input#tod4").val()); //get timestamp

//value end
var end = Date.parse($("input#toa4").val()); //get timestamp

totalHours = NaN;

if (start < end) {
  totalHours = Math.floor((end - start) / 1000 / 60 / 60); //milliseconds: /1000 / 60 / 60

  days = Math.round(totalHours / 24);

} else {
  alert('The end date and time of the journey should not be less than the start date and time.');
}
$("#totalhour").val(totalHours);

$("#daysoftravel4").val(days);

}

 
</script>

</body>

</html>