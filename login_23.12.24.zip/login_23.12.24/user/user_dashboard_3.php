<html>
<body>
<script type="text/javascript" src="condition.js"></script>
<link rel="icon" href="fevicon.png" />



<?php
//include auth_session.php file on all user panel pages
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');
?>

<style>
    body{
  overflow-x: hidden;
}
#employer-post-new-job .res-steps-container .res-steps {
    width: 25%;
    text-align: center;
    float: left;
    cursor: pointer
}

#employer-post-new-job .res-steps-container .res-steps .res-step-bar {
    -webkit-border-radius: 50% !important;
    -moz-border-radius: 50% !important;
    -ms-border-radius: 50% !important;
    border-radius: 50% !important;
    background: #0aa7e1;
    display: inline-block;
    height: 40px;
    width: 40px;
    margin-top: 10px;
    text-align: center;
    color: #fff;
    padding-top: 7px;
    font-size: 20px
}

#employer-post-new-job .res-steps-container .res-steps .res-progress-title {
    text-align: center;
    font-size: 15px;
    padding-top: 10px;
    display: block
}

#employer-post-new-job .res-steps-container .res-steps .res-progress-bar {
    height: 5px;
    background: #0aa7e1;
    width: 50%;
    margin: -22px 0 0 50%;
    float: left
}

#employer-post-new-job .res-steps-container .res-step-two .res-progress-bar, #employer-post-new-job .res-steps-container .res-step-three .res-progress-bar, #employer-post-new-job .res-steps-container .res-step-four .res-progress-bar,#employer-post-new-job .res-steps-container .res-step-five .res-progress-bar {
    width: 100%;
    margin-left: 0%
}

#employer-post-new-job .res-steps-container .res-step-four .res-progress-bar {
    width: 50%;
    margin-right: 50%
}

#employer-post-new-job .res-steps-container .res-step-five .res-progress-bar {
    width: 50%;
    margin-right: 50%
}
#employer-post-new-job .res-step-form {
    border: 1px solid #d2d2d2;
    box-shadow: 0px 6px 4px -2px silver;
    position: absolute
    
}
#employer-post-new-job .res-step-form h3 {
    margin: 10px 0;
    color: #0aa7e1;
    font-size: 18px
}

#employer-post-new-job .res-step-form .form-horizontal label {
    font-weight: normal
}

#employer-post-new-job .res-form-two, #employer-post-new-job .res-form-three, #employer-post-new-job .res-form-four,#employer-post-new-job .res-form-three {
    left: 100%
}


#employer-post-new-job .active .res-step-bar {
    background: #f19b20 !important
}

#employer-post-new-job .active .res-progress-title {
    color: #0aa7e1
}
</style>
</head><br><br>
 <body>
 <div class="container" style="border:1px solid black; padding:15px; background-color:#fff; border-radius:5px;">
<br>
<form method="POST" action="#" enctype="multipart/form-data">
    <div class="row">
       <div class="col">
          <label for="exampleFormControlInput1" class="form-label">First Name</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fname" placeholder="First Name" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Last Name</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="lname" placeholder="Last Name" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="branch" class="form-label">Select your branch</label>
          <select class="form-select" id="branch" aria-label="First Name" name='branch' required>
            <option value="">Select Branch</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From branches");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['br_id'] . " " . $row['br_name'] . "'>" . $row['br_id'] . " " . $row['br_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        <div class="col">
          <label for="desig" class="form-label">Designation</label>
          <select class="form-select" id="desig" aria-label="First Name" name="designation" onChange="myFunction2()" required>
            <option value="$designation">Select your designation</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From designation");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['designation_name'] . "'>" . $row['designation_name'] . "</option>";
            }
            ?>
          </select>
        </div>
<br>
     <div class="container" style="padding:10px; margin-top:10px; background-color:#fff; border-radius:5px;">
         <section id="employer-post-new-job">
        	 <div class="container">	
                 <div class="row">	
	    			  <div class="row">                    
						  <div class="col-xl-10 col-xs-offset-1" id="container">
							   <div class="res-steps-container">
									<div class="res-steps res-step-one active" data-class=".res-form-one">
										<div class="res-step-bar">1</div>
										<div class="res-progress-bar"></div>
										<div class="res-progress-title">Part 1</div>
									</div>
									<div class="res-steps res-step-two" data-class=".res-form-two">
										<div class="res-step-bar">2</div>
										<div class="res-progress-bar"></div>
										<div class="res-progress-title">Part 2</div>
									</div>
									<div class="res-steps res-step-three" data-class=".res-form-three">
										<div class="res-step-bar">3</div>
										<div class="res-progress-bar"></div>
										<div class="res-progress-title">Part 3</div>
									</div>
									<div class="res-steps res-step-four" data-class=".res-form-four">
										<div class="res-step-bar">4</div>
										<div class="res-progress-bar"></div>
										<div class="res-progress-title">Part 4</div>
									</div>
                                    <!-- <div class="res-steps res-step-five" data-class=".res-form-five">
										<div class="res-step-bar">5</div>
										<div class="res-progress-bar"></div>
										<div class="res-progress-title">Add Title & Description 5</div>
									</div> -->
                                    
									<div class="clearfix">&nbsp;</div>
									<div class="clearfix">&nbsp;</div>
									<div class="clearfix">&nbsp;</div>
                                	<center>
									<div class="res-step-form col-md-10 res-form-one">
									                                    
									</div>                         
								    </center>
                                	
									<center>
									<div class="res-step-form col-md-10 res-form-two">
									<h3 class="text-center">Add Title &amp; Description 2</h3>
									</div>
                                	</center>
                                	
									<center>
								    <div class="res-step-form col-md-10 res-form-three">
									<h3 class="text-center">Add Title &amp; Description 3</h3>
									</div>
                                    </center>
								
                                   <center>
								   <div class="res-step-form col-md-10 res-form-four">
								   <h3 class="text-center">Add Title &amp; Description 4</h3>
								   </div>
                                   </center>
                                
								   <center>
								   <div class="res-step-form col-md-10 res-form-five">
								   <h3 class="text-center">Add Title &amp; Description 5</h3>
								   </div>
                                   </center>
							 </div>
		     			 </div>
	                 </div>
	             </div>
	         </div>
         </section>
     </div>

   				<script src="../bower_components/jquery/dist/jquery.min.js"></script>
				<!-- Bootstrap Core JavaScript -->
				<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
     			<!-- Metis Menu Plugin JavaScript -->
				<script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>
				<!-- Custom Theme JavaScript -->
  				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
				<script src="dist/js/sb-admin-2.js"></script>
				<script src="dist/jquery-1.3.2.js" type="text/javascript"></script>
				<script src="dist/jquery.validate.js" type="text/javascript"></script>
				<!-- <script type="text/javascript">
            
            		jQuery(function(){
                	jQuery("#id").validate({
                    expression: "if (VAL.match(/^[a-z]$/)) return true; else return false;",
                    message: "Should be a valid id"
                	});
                	jQuery("#password").validate({
                    expression: "if (VAL.match(/^[a-z]$/)) return true; else return false;",
                    message: "Should be a valid password"
                	});
                
            		});
            	</script> -->
        
        		<script>
            		$(document).ready(function(){
					var steps = ['.res-step-one','.res-step-two','.res-step-three','.res-step-four','.res-step-five'];
					var i = 1;

					$(".res-step-form .res-btn-orange").click(function(){
						var getClass = $(this).attr('data-class');
						$(".res-steps").removeClass('active');
						$(steps[i]).addClass('active');
						i++;
						if(getClass != ".res-form-four")
						{
							$(getClass).animate({left: '-150%'},500, function(){$(getClass).css('left', '150%');});
							$(getClass).next().animate({left: '0%'}, 500, function(){$(this).css('display','block');
						}
						);
						}
					});
    

					/* step back */
					$(".res-step-form .res-btn-gray").click(function(){
						var getClass = $(this).attr('data-class');
						$(".res-steps").removeClass('active');
						i--;
						$(steps[i-1]).addClass('active');
						$(getClass).prev().css('left','-150%')
						$(getClass).animate({left: '150%'}, 500);
						$(getClass).prev().animate({left: '0%'}, 500)
					});

					/* click from top bar steps */
					$('.res-step-one').click(function(){
						if(!$(this).hasClass('active')){
							$(".res-steps").removeClass('active');
							i = 0;
							$(steps[i]).addClass('active');
							i++;
							$('.res-form-one').css('left','-150%');
							$('.res-form-two, .res-form-three, .res-form-four,.res-form-five').animate({
								left: '150%'
							}, 500);
							$('.res-form-one').animate({
								left: '0%'
							}, 500);
						}
					});

					$('.res-step-two').click(function(){
						if(!$(this).hasClass('active')){
							$(".res-steps").removeClass('active');
							i = 1;
							$(steps[i]).addClass('active');
							i++;
							$('.res-form-two').css('left','-150%');
							$('.res-form-one, .res-form-three, .res-form-four,.res-form-five').animate({
								left: '150%'
							}, 500);
							$('.res-form-two').animate({
								left: '0%'
							}, 500);
						}
					});

					$('.res-step-three').click(function(){
						if(!$(this).hasClass('active')){
							$(".res-steps").removeClass('active');
							i = 2;
							$(steps[i]).addClass('active');
							i++;
							$('.res-form-three').css('left','-150%');
							$('.res-form-one, .res-form-two, .res-form-four,.res-form-five').animate({
								left: '150%'
							}, 500);
							$('.res-form-three').animate({
								left: '0%'
							}, 500);
						}
					});

					$('.res-step-four').click(function(){
						if(!$(this).hasClass('active')){
							$(".res-steps").removeClass('active');
							i = 3;
							$(steps[i]).addClass('active');
							i++;
							$('.res-form-four').css('left','-150%');
							$('.res-form-one, .res-form-two, .res-form-three,.res-form-five').animate({
								left: '150%'
							}, 500);
							$('.res-form-four').animate({
								left: '0%'
							}, 500);
						}
					});
					$('.res-step-five').click(function(){
						if(!$(this).hasClass('active')){
							$(".res-steps").removeClass('active');
							i = 3;
							$(steps[i]).addClass('active');
							i++;
							$('.res-form-five').css('left','-150%');
							$('.res-form-one, .res-form-two, .res-form-three,.res-form-four').animate({
								left: '150%'
							}, 500);
							$('.res-form-five').animate({
								left: '0%'
							}, 500);
						}
					});
					});
        	 </script>
</body>

</html>
