<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include necessary files
include("../tcpdf/tcpdf.php");
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');

// Get user ID from query parameters
if (isset($_GET['uid']) && !empty($_GET['uid'])) {
    $userid = $_GET['uid'];
} else {
    die("User ID is missing.");
}

// Query the database
$result = mysqli_query($con, "SELECT * FROM travel_data WHERE tid='$userid'");

if (!$result) {
    die("Error in query execution: " . mysqli_error($con));
}

if (mysqli_num_rows($result) > 0) {
    // Fetch data
    $row = mysqli_fetch_assoc($result);

    // Assign data to variables
    $fname = $row['first_name'];
    $lname = $row['last_name'];
    $branch = $row['branch'];
    $designation = $row['designation'];
    $totalamount = $row['totalamount'];

 //-------Part 1 variables declaration--- 
  
    $city1 = $row['p1_citytype'];
    $fromstation1 = $row['p1_fromstation'];
    $tostation1 = $row['p1_tostation'];
    $kmoftravel1 = $row['p1_km'];
    $tod1 = $row['p1_startdate'];
    $toa1 = $row['p1_enddate'];
    $daysoftravel1 = $row['p1_dadays'];  
    $darate1 = $row['p1_darate'];
    $dacharges1 = $row['p1_dacharges'];
    $lccharges1 = $row['p1_lccharges'];
    $cccharges1 = $row['p1_cccharges'];
    $ticketamount1= $row['p1_ticketamount'];
  
  //-------Part 2 variables declaration---
  $city2 = $row['p2_citytype'];
  $fromstation2 = $row['p2_fromstation'];
  $tostation2 = $row['p2_tostation'];
  $kmoftravel2 = $row['p2_km'];
  $tod2 = $row['p2_startdate'];
  $toa2 = $row['p2_enddate'];
  $daysoftravel2 = $row['p2_dadays'];  
  $darate2 = $row['p2_darate'];
  $dacharges2 = $row['p2_dacharges'];
  $lccharges2 = $row['p2_lccharges'];
  $cccharges2 = $row['p2_cccharges'];
  $ticketamount2= $row['p2_ticketamount'];

//-------Part 3 variables declaration---
$city3 = $row['p3_citytype'];
$fromstation3 = $row['p3_fromstation'];
$tostation3 = $row['p3_tostation'];
$kmoftravel3 = $row['p3_km'];
$tod3 = $row['p3_startdate'];
$toa3 = $row['p3_enddate'];
$daysoftravel3 = $row['p3_dadays'];  
$darate3 = $row['p3_darate'];
$dacharges3 = $row['p3_dacharges'];
$lccharges3 = $row['p3_lccharges'];
$cccharges3 = $row['p3_cccharges'];
$ticketamount3= $row['p3_ticketamount'];

//-------Part 4 variables declaration---
$city4 = $row['p4_citytype'];
$fromstation4 = $row['p4_fromstation'];
$tostation4 = $row['p4_tostation'];
$kmoftravel4 = $row['p4_km'];
$tod4 = $row['p4_startdate'];
$toa4 = $row['p4_enddate'];
$daysoftravel4 = $row['p4_dadays'];  
$darate4 = $row['p4_darate'];
$dacharges4 = $row['p4_dacharges'];
$lccharges4 = $row['p4_lccharges'];
$cccharges4 = $row['p4_cccharges'];
$ticketamount4= $row['p4_ticketamount'];

} else {
    die("No data found for the provided User ID.");
}


// Generate the PDF
class PDF extends TCPDF
{
    // Page header
    public function Header()
    {
        $this->SetFont('helvetica', 'B', 12);
        $this->Cell(0, 10, 'THE AKOLA URBAN CO-OPERATIVE BANK LTD., AKOLA', 0, 1, 'C');
        $this->Ln(5);
    }

    // Page footer
    public function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->getAliasNumPage() . '/' . $this->getAliasNbPages(), 0, 0, 'C');
    }
}

// Create a new PDF document
$pdf = new PDF();
$pdf->SetMargins(20, 10, 20);
$pdf->AddPage('L', 'A4'); // A4 in landscape orientation
$pdf->SetFont('helvetica', '', 12);

$pdf->SetMargins(10, 10, 10); // Left, top, right margins (10mm each)
$pdf->SetAutoPageBreak(true, 10); // Bottom margin (10mm)


$html = <<<EOD
<h2 style="text-align:center">TA Bill Details</h2>
<hr>
<h4>Employee Information:</h4>
<table style="width: 100%; margin: 0 auto; border: none; margin-left: 20px;  border-spacing: 30px 0">
    <tr>
        <td style="width: 45%; font-weight: bold; padding-left: 20px;">First Name</td>
        <td style="width: 10%; font-weight: bold; padding-left: 20px;">:</td>
        <td style="width: 55%; padding-left: 10px; padding-right: 20px;">{$fname}</td>
    </tr>
    <tr>
        <td style="width: 45%; font-weight: bold; padding-left: 20px;">Last Name</td>
        <td style="width: 10%; font-weight: bold; padding-left: 20px;">:</td>
        <td style="width: 55%; padding-left: 10px; padding-right: 20px;">{$lname}</td>
    </tr>
    <tr>
        <td style="width: 45%; font-weight: bold;">Branch</td>
        <td style="width: 10%; font-weight: bold; padding-left: 20px;">:</td>
        <td style="width: 55%; padding-left: 10px; padding-right: 20px;">{$branch}</td>
    </tr>
    <tr>
        <td style="width: 45%; font-weight: bold; padding-left: 20px;">Designation</td>
        <td style="width: 10%; font-weight: bold; padding-left: 20px;">:</td>
        <td style="width: 55%; padding-left: 10px; padding-right: 20px;">{$designation}</td>
    </tr>
    <tr>
        <td style="width: 45%; font-weight: bold; padding-left: 20px;">Total Amount</td>
        <td style="width: 10%; font-weight: bold;">:</td>
        <td style="width: 55%; padding-right: 20px;">{$totalamount}</td>
    </tr>
    <tr>
        <td style="width: 45%; font-weight: bold; padding-left: 20px;">Remark</td>
        <td style="width: 10%; font-weight: bold;">:</td>
        <td style="width: 55%; padding-left: 10px; padding-right: 20px;">{$remark}</td>
    </tr>
</table>

<h4 style="text-align:center;">Travel Details</h4>
<table style="width: 100%; margin: 10px auto; border-collapse: collapse; text-align: center; align-items: center;">
    <thead>
        <tr>
            <th style="border: 1px solid #000; padding: 5px;">From Station</th>
            <th style="border: 1px solid #000; padding: 5px;">Depa. Date & Time</th>
            <th style="border: 1px solid #000; padding: 5px;">To Station</th>
            <th style="border: 1px solid #000; padding: 5px;">Arrival Date & Time</th>
            <th style="border: 1px solid #000; padding: 1px;">KM</th>
            <th style="border: 1px solid #000; padding: 5px;">Days</th>
            <th style="border: 1px solid #000; padding: 5px;">Rate</th>
            <th style="border: 1px solid #000; padding: 5px;">DA Charges</th>
            <th style="border: 1px solid #000; padding: 5px;">Lodging Charges</th>
            <th style="border: 1px solid #000; padding: 5px;">Bus/Railway Fare</th>
            <th style="border: 1px solid #000; padding: 20px;">Conveyance Charges</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($fromstation1) && $fromstation1 != 0) { ?>
            <tr>
                <td style="border: 1px solid #000; padding: 5px;">$fromstation1</td>
                <td style="border: 1px solid #000; padding: 5px;">$tod1</td>
                <td style="border: 1px solid #000; padding: 5px;"> $tostation1</td>
                <td style="border: 1px solid #000; padding: 5px;">$toa1</td>
                <td style="border: 1px solid #000; padding: 5px;">$kmoftravel1</td>
                <td style="border: 1px solid #000; padding: 5px;">$daysoftravel1</td>
                <td style="border: 1px solid #000; padding: 5px;">$darate1</td>
                <td style="border: 1px solid #000; padding: 5px;">$dacharges1</td>
                <td style="border: 1px solid #000; padding: 5px;">$lccharges1</td>
                <td style="border: 1px solid #000; padding: 5px;">$ticketamount1</td>
                <td style="border: 1px solid #000; padding: 5px;">$cccharges1</td>
            </tr>
        <?php } ?>
        
         <?php if (!empty($fromstation1) && $fromstation1 != 0) {  ?>
    <tr>
        <td style="border: 1px solid #000; padding: 5px;">$fromstation2</td>
        <td style="border: 1px solid #000; padding: 5px;">$tod2</td>
        <td style="border: 1px solid #000; padding: 5px;">$tostation2</td>
        <td style="border: 1px solid #000; padding: 5px;">$toa2</td>
        <td style="border: 1px solid #000; padding: 5px;">$kmoftravel2</td>
        <td style="border: 1px solid #000; padding: 5px;">$daysoftravel2</td>
        <td style="border: 1px solid #000; padding: 5px;">$darate2</td>
        <td style="border: 1px solid #000; padding: 5px;">$dacharges2</td>
        <td style="border: 1px solid #000; padding: 5px;">$lccharges2</td>
        <td style="border: 1px solid #000; padding: 5px;">$ticketamount2</td>
        <td style="border: 1px solid #000; padding: 5px;">$cccharges2</td>
    </tr>
<?php } ?>
 
<tr>
        <td style="border: 1px solid #000; padding: 5px;">$fromstation3</td>
        <td style="border: 1px solid #000; padding: 5px;">$tod3</td>
        <td style="border: 1px solid #000; padding: 5px;">$tostation3</td>
        <td style="border: 1px solid #000; padding: 5px;">$toa3</td>
        <td style="border: 1px solid #000; padding: 5px;">$kmoftravel3</td>
        <td style="border: 1px solid #000; padding: 5px;">$daysoftravel3</td>
        <td style="border: 1px solid #000; padding: 5px;">$darate3</td>
        <td style="border: 1px solid #000; padding: 5px;">$dacharges3</td>
        <td style="border: 1px solid #000; padding: 5px;">$lccharges3</td>
        <td style="border: 1px solid #000; padding: 5px;">$ticketamount3</td>
        <td style="border: 1px solid #000; padding: 5px;">$cccharges3</td>
    </tr>
<?php } ?>
<tr>
        <td style="border: 1px solid #000; padding: 5px;">$fromstation4</td>
        <td style="border: 1px solid #000; padding: 5px;">$tod4</td>
        <td style="border: 1px solid #000; padding: 5px;">$tostation4</td>
        <td style="border: 1px solid #000; padding: 5px;">$toa4</td>
        <td style="border: 1px solid #000; padding: 5px;">$kmoftravel4</td>
        <td style="border: 1px solid #000; padding: 5px;">$daysoftravel4</td>
        <td style="border: 1px solid #000; padding: 5px;">$darate4</td>
        <td style="border: 1px solid #000; padding: 5px;">$dacharges4</td>
        <td style="border: 1px solid #000; padding: 5px;">$lccharges4</td>
        <td style="border: 1px solid #000; padding: 5px;">$ticketamount4</td>
        <td style="border: 1px solid #000; padding: 5px;">$cccharges4</td>
    </tr>
<?php } ?>

</tbody>
</table>
<tr style="text-align:right;padding: top 100px;"> Name</tr>
EOD;

// Move cursor to the right with a specific X coordinate (adjust to your needs)
$pdf->SetX(150);  // Set X position to 150mm from the left edge (you can adjust the value)



// Add some space between "Name" and "Signature"
$pdf->Ln(5);  // 5mm line break



// Add HTML to the PDF
$pdf->writeHTML($html);

// Output the PDF
ob_end_clean();
$pdf->Output("{$fname}_TA_Bill.pdf", 'I');
?>
