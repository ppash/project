


<?php
include("header.php");
include("common/auth_session.php");
require('common/db.php');
// for deleting user
if(isset($_GET['id']))
{
$adminid=$_GET['id'];
$msg=mysqli_query($con,"delete from user where id='$adminid'");
if($msg)
{
echo "<script>alert('Data deleted');</script>";
}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>TA Bill System</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="style.css" />

    <style>
        #datatablesSimple {
            width: 100%;
            border-collapse: collapse;
        }

        #datatablesSimple th, #datatablesSimple td {
            border: 1px solid #ddd;
            padding: 8px 12px;
            text-align: left;
        }

        #datatablesSimple th {
            background-color: #f2f2f2;
        }

        #datatablesSimple tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        #datatablesSimple tr:hover {
            background-color: #e9e9e9;
        }
    </style>


</head>
<body>
<main class="container-fluid px-4">
                    <div class="container-fluid px-4">
                        <!-- <h1 class="mt-4">Manage users</h1> -->
                        <ol class="breadcrumb mb-4">
                            <!-- <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Travel Bills</li> -->
                        </ol>
            
                        <div class="card mb-4" style=" background:linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),url('./user/aucb_wm.png') no-repeat; background-position: center; background-size:35%;">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                   Travel Bills Details
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                  <th>Sno.</th>
                                  <th>First Name</th>
                                  <th>Last Name</th>
                                  <th>Branch</th>
                                  <th>Application Date</th>
                                  <th>Status</th> 
                                  <th style="text-align:center;">View</th>
                                  <th style="text-align:center;">Edit</th>                                                                                      
                                  </tr>
                                  </thead>
                                  
                                    <tbody>
                             <?php $ret=mysqli_query($con,"select * from travel_data where document_name IS NOT NULL AND document_name <> '' order by tid desc");
                              $cnt=1;
                              while($row=mysqli_fetch_array($ret))
                              {?>
                              <tr>
                                  <td><?php echo $cnt;?></td>
                                  <td><?php echo $row['first_name'];?></td>
                                  <td><?php echo $row['last_name'];?></td>
                                  <td><?php echo $row['branch'];?></td>
                                  <td><?php echo $row['application_date'];?></td>
                                  <td><?php echo $row['manager_approval'];?></td>
                                                     
                                  <td style="text-align:center;">
                                      <a href="user-profile.php?uid=<?php echo $row['tid'];?>" onClick="myFunction2()" > 
                                         <i class="fas fa-eye"></i>
                                      </a>
                                  </td>
                                  <td style="text-align:center;">  
                                      <a href="edit.php?uid=<?php echo $row['tid'];?>"> 
                                         <i class="fas fa-edit"></i>
                                      </a>    
                                 </td>                                 
                              </tr>
                              
                              <?php $cnt=$cnt+1; }?>
                                 </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
 <script src="js/datatables-simple-demo.js"></script>
 <script type="text/javascript" src="admin_condition.js"></script>
</body>
</html>