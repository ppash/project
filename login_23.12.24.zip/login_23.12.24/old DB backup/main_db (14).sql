-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2024 at 03:00 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `br_id` int(11) NOT NULL,
  `br_name` varchar(256) NOT NULL,
  `br_address` varchar(512) NOT NULL,
  `br_mail` varchar(50) NOT NULL,
  `br_phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`br_id`, `br_name`, `br_address`, `br_mail`, `br_phone`) VALUES
(1001, 'Main Branch, Akola', '\'JANKALYAN\' OLD COTTON MARKET, AKOLA-444 001', 'aucb_main@aucbakola.com', '7242442251'),
(1002, 'Ramdaspeth,Akola', 'DATTA MANDIR CHOWK, RAMDAS PETH, AKOLA - 444 001', 'aucb_ramdaspeth@aucbakola.com', '7242434543'),
(1003, 'Karanja', 'MAIN RD, COTTON MARKET, NEAR APMC. KARANJA - 444 105', 'aucb_karnja@aucbakola.com', '7256222126'),
(1004, 'Mangrulpir', 'INFRONT OF SBI MAIN RD, MANGRULPIR - 444 403', 'aucb_mangrulpir@aucbakola.com', '7253230255'),
(1005, 'Adarsh Colony,Akola', 'POONAM COMPLEX,  GORAKSHAN RD, INCOME TAX CHOWK, AKOLA 444 004', 'aucb_adarshcolony@aucbakola.com', '7242459536'),
(1006, 'Balapur ', 'NEAR STATE BANK OF INDIA, BALAPUR DIST. AKOLA - 444 302', 'aucb_balapur@aucbakola.com', '7257232116'),
(1007, 'Tajnapeth,Akola', 'NEAR HDFC BANK, JILLHA PARISHAD ROAD, AKOLA - 444 001', 'aucb_tajnapeth@aucbakola.com', '7242438304'),
(1008, 'Murtizapur ', 'STATION ROAD, MURTIZAPUR  DIST AKOLA 444 107', 'aucb_murtizapur@aucbakola.com', '07256 243552'),
(1009, 'Hiwarkhed', 'MAIN ROAD, HIWARKHED 444103', 'aucb_hiwarkhed@aucbakola.com', '7258228209'),
(1010, 'Akot', 'LAKKAD GUNJ, HIWARKHED RD, AKOT DIST AKOLA - 444 101', 'aucb_akot@aucbakola.com', '7258224184'),
(1011, 'Malegaon', 'SHRI NAWASTHALE BUILDING MAIN RD. MALEGAON - 444 503', 'aucb_malegaon@aucbakola.com', '7254231271'),
(1012, 'Wadegaon', 'SHRI JAYRAM KALE COMPLEX, MAIN RD, WADEGAON - 444 502', 'aucb_wadegaon@aucbakola.com', '7257231144'),
(1013, 'Telhara', 'INFRONT OF  SHIVAJI SCHOOL, BUS STAND ROAD, TELHARA - 444 108', 'aucb_telhara@aucbakola.com', '7258231030'),
(1014, 'Sitabuldi,Nagpur', 'SAGAR TOWER, 2ND FLOOR, BESIDE NARESHCHANDRA & CO. PANDIT MALVIYA RD, SITABULDI, NAGPUR - 440 012', 'aucb_sitabuldi@aucbakola.com', '7122527199'),
(1015, 'Jalgaon', 'NATRAJ HALL OPP.PADMALAYA GOVT. REST HOUSE, JAYKISANWADI JALGAON - 425 001', 'aucb_jalgaon@aucbakola.com', '2572220197'),
(1016, 'Jaistambh Chowk, Amravati', 'MAHAVIR PLAZA COMPLEX, JAISTAMBH CHOWK, AMRAVATI - 444 601', 'aucb_jaisthambh@aucbakola.com', '7212679911'),
(1017, 'Yavatmal', 'SHARDA SADAN, AWDHOOT WADI, YAVATMAL - 445001', 'aucb_yavatmal@aucbakola.com', '7232241358'),
(1018, 'Daryapur', 'BANOSA ROAD, DARYAPUR - 444 803', 'aucb_daryapur@aucbakola.com', '7224234782'),
(1019, 'Rajapeth,Amravati', 'DEORANKAR NAGAR,NEAR SAMARTH HIGHSCHOOL,BADNERA ROAD, RAJAPETH AMRAVATI - 444601\r\n\r\n\r\n\r\n\r\n\r\n', 'aucb_rajapeth@aucbakola.com', '7212575501'),
(1020, 'Kalbadevi,Mumbai', '19,21/23 KARNANI HOUSE, VITHOBA LANE, VITTHALWADI, MUMBAI - 400 002', 'aucb_kalbadevi@aucbakola.com', '222406259'),
(1021, 'Gandhibag,Nagpur', '2ND FLOOR AHILYA COMPLEX NEAR MEDICINE MARKET AGRESEN CHOWK GANDHIBAG, NAGPUR - 440 002', 'aucb_gandhibag@aucbakola.com', '7122732750'),
(1022, 'APMC,Akola', 'GANGA NAGAR,BALAPUR ROAD,AKOLA - 444 001', 'aucb_apmc@aucbakola.com', '7242442250'),
(1023, 'Chandrapur', 'RAMKRUSHNA APPTT. GANJ WARD, CHANDRAPUR - 442 402', 'aucb_chandrapur@aucbakola.com', '7172256551'),
(1024, 'Wardha', 'RADHE COMPLEX SOCIELIST CHOWK, WARDHA - 442 008', 'aucb_wardha@aucbakola.com', '7152244554'),
(1025, 'Nanded', 'GROUND FLOOR, PATIL PLAZA, TAJ PATIL HOTEL,VISHNU COMPLEX, VIP ROAD,NANDED - 431605\r\n', 'aucb_nanded@aucbakola.com', '2462250370'),
(1026, 'Dabki Road,Akola', 'NEAR BHIKAMCHAND, KHANDELWAL HIGH SCHOOL,  GODBOLE PLOTS, DABKI ROAD, AKOLA - 444 002', 'aucb_dabkiroad@aucbakola.com', '7242439616'),
(1027, 'Civil Line,Akola ', '\'MAHALAXMI\'COMPLEX, OPP.BAGDI HOSITAL,AMANKHA PLOT,AKOLA-444001', 'aucb_civilline@aucbakola.com', '7242453317'),
(1028, 'Aurangabad', 'GOPICHAND COMPLEX, OPP. APNA HOSPITAL JALNA RD, AURANGABAD - 431 001', 'aucb_aurangabad@aucbakola.com', '2402344500'),
(1029, 'Nashik', 'NEAR MEHAR PLAZA BUILDING SAMANT HOUSE, ABOVE INDIAN BANK, OLD AGRA ROAD, NASHIK - 422 002', 'aucb_nasik@aucbakola.com', '2532318147'),
(1030, 'Brahman Sabha,Akola', 'JATHARPETH CHOWK, NEAR UTSAV MANGALKARYALAYA, AKOLA - 444 001', 'aucb_bsec@aucbakola.com', '7242490561'),
(1031, 'Subhashmarg,Indore', 'NETAJI SHUBHSAH MARG, INDORE -  452 007', 'aucb_subhashmarg@aucbakola.com', '7312531594'),
(1032, 'Malharganj,Indore', '19/2 DALLAI PATTI MALHARGANJ, INDORE- 452 002', 'aucb_malharganj@aucbakola.com', '7312411668'),
(1033, 'H.I.G. Colony,Indore', 'S-43, BEHIND KHRISTAN EMINENT SCHOOL MIG COLONY, INDORE - 452 010', 'aucb_higcolony@aucbakola.com', '7312553888'),
(1034, 'Sanyogitaganj,Indore', '47/2 SANYOGITA GANJ INDORE - 452 007', 'aucb_sanyogitaganj@aucbakola.com', '7312702355'),
(9999, 'Head Office', 'Jankalyan, 58-59, Toshniwal Layout, Near Govt. Milk Scheme, Murtizapur Road, Akola', 'aucb_main@aucbakola.com', '2453850-54');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `c_id` int(50) NOT NULL,
  `city_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`c_id`, `city_name`) VALUES
(1, 'Metro City'),
(2, 'District Centre'),
(3, 'Taluka and Below Centre'),
(4, 'Nagpur'),
(5, 'Nashik'),
(6, 'Aurangabad'),
(7, 'Nanded'),
(8, 'Akola'),
(9, 'Amravati'),
(10, 'Indore');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `d_id` int(11) NOT NULL,
  `designation_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`d_id`, `designation_name`) VALUES
(1, 'Dy. CEO/Chief Manager'),
(3, 'Branch Head'),
(5, 'Officer'),
(6, 'Executive'),
(7, 'Messenger/Driver');

-- --------------------------------------------------------

--
-- Table structure for table `travel_data`
--

CREATE TABLE `travel_data` (
  `username` varchar(50) DEFAULT NULL,
  `tid` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `designation` text DEFAULT NULL,
  `branch` text DEFAULT NULL,
  `max_da` int(100) DEFAULT NULL,
  `max_lc` int(100) DEFAULT NULL,
  `max_cc` int(100) DEFAULT NULL,
  `p1_citytype` varchar(50) DEFAULT NULL,
  `p1_fromstation` varchar(50) DEFAULT NULL,
  `p1_tostation` varchar(50) DEFAULT NULL,
  `p1_startdate` datetime DEFAULT NULL,
  `p1_enddate` datetime DEFAULT NULL,
  `p1_totaldays` int(20) DEFAULT NULL,
  `p1_km` int(100) DEFAULT NULL,
  `p1_daradio` varchar(5) DEFAULT NULL,
  `p1_darate` int(50) DEFAULT NULL,
  `p1_dadays` int(50) DEFAULT NULL,
  `p1_dacharges` int(50) DEFAULT NULL,
  `p1_lcradio` varchar(5) DEFAULT NULL,
  `p1_lcrate` int(50) DEFAULT NULL,
  `p1_lcdays` int(50) DEFAULT NULL,
  `p1_lccharges` int(50) DEFAULT NULL,
  `p1_ccradio` varchar(5) DEFAULT NULL,
  `p1_ccrate` int(50) DEFAULT NULL,
  `p1_ccdays` int(50) DEFAULT NULL,
  `p1_cccharges` int(50) DEFAULT NULL,
  `p1_ticketradio` varchar(5) DEFAULT NULL,
  `p1_ticketcount` int(50) DEFAULT NULL,
  `p1_ticketamount` int(50) DEFAULT NULL,
  `p2_citytype` text DEFAULT NULL,
  `p2_fromstation` varchar(50) DEFAULT NULL,
  `p2_tostation` varchar(50) DEFAULT NULL,
  `p2_startdate` datetime DEFAULT NULL,
  `p2_enddate` datetime DEFAULT NULL,
  `p2_totaldays` int(20) DEFAULT NULL,
  `p2_km` int(100) DEFAULT NULL,
  `p2_daradio` varchar(5) DEFAULT NULL,
  `p2_darate` int(50) DEFAULT NULL,
  `p2_dadays` int(50) DEFAULT NULL,
  `p2_dacharges` int(50) DEFAULT NULL,
  `p2_lcradio` varchar(5) DEFAULT NULL,
  `p2_lcrate` int(50) DEFAULT NULL,
  `p2_lcdays` int(50) DEFAULT NULL,
  `p2_lccharges` int(50) DEFAULT NULL,
  `p2_ccradio` varchar(5) DEFAULT NULL,
  `p2_ccrate` int(50) DEFAULT NULL,
  `p2_ccdays` int(50) DEFAULT NULL,
  `p2_cccharges` int(50) DEFAULT NULL,
  `p2_ticketradio` int(10) DEFAULT NULL,
  `p2_ticketcount` int(10) DEFAULT NULL,
  `p2_ticketamount` int(10) DEFAULT NULL,
  `p3_citytype` varchar(50) DEFAULT NULL,
  `p3_fromstation` varchar(50) DEFAULT NULL,
  `p3_tostation` varchar(50) DEFAULT NULL,
  `p3_startdate` datetime DEFAULT NULL,
  `p3_enddate` datetime DEFAULT NULL,
  `p3_totaldays` int(20) DEFAULT NULL,
  `p3_km` int(100) DEFAULT NULL,
  `p3_daradio` varchar(5) DEFAULT NULL,
  `p3_darate` int(50) DEFAULT NULL,
  `p3_dadays` int(50) DEFAULT NULL,
  `p3_dacharges` int(50) DEFAULT NULL,
  `p3_lcradio` varchar(5) DEFAULT NULL,
  `p3_lcrate` int(50) DEFAULT NULL,
  `p3_lcdays` int(50) DEFAULT NULL,
  `p3_lccharges` int(50) DEFAULT NULL,
  `p3_ccradio` varchar(5) DEFAULT NULL,
  `p3_ccrate` int(50) DEFAULT NULL,
  `p3_ccdays` int(50) DEFAULT NULL,
  `p3_cccharges` int(50) DEFAULT NULL,
  `p3_ticketradio` varchar(5) DEFAULT NULL,
  `p3_ticketcount` int(50) DEFAULT NULL,
  `p3_ticketamount` int(50) DEFAULT NULL,
  `p4_citytype` varchar(100) DEFAULT NULL,
  `p4_fromstation` varchar(100) DEFAULT NULL,
  `p4_tostation` varchar(100) DEFAULT NULL,
  `p4_startdate` datetime DEFAULT NULL,
  `p4_enddate` datetime DEFAULT NULL,
  `p4_totaldays` int(10) DEFAULT NULL,
  `p4_km` int(10) DEFAULT NULL,
  `p4_daradio` varchar(5) DEFAULT NULL,
  `p4_darate` int(10) DEFAULT NULL,
  `p4_dadays` int(10) DEFAULT NULL,
  `p4_dacharges` int(10) DEFAULT NULL,
  `p4_lcradio` varchar(5) DEFAULT NULL,
  `p4_lcrate` int(10) DEFAULT NULL,
  `p4_lcdays` int(10) DEFAULT NULL,
  `p4_lccharges` int(10) DEFAULT NULL,
  `p4_ccradio` varchar(5) DEFAULT NULL,
  `p4_ccrate` int(10) DEFAULT NULL,
  `p4_ccdays` int(10) DEFAULT NULL,
  `p4_cccharges` int(10) DEFAULT NULL,
  `p4_ticketradio` varchar(5) DEFAULT NULL,
  `p4_ticketcount` int(10) DEFAULT NULL,
  `p4_ticketamount` int(10) DEFAULT NULL,
  `lodging_bills` varchar(100) DEFAULT NULL,
  `tickets_document` varchar(100) DEFAULT NULL,
  `totalamount` int(50) NOT NULL,
  `remark` text DEFAULT NULL,
  `admin_comment` varchar(100) DEFAULT NULL,
  `status` text NOT NULL,
  `approval_date` varchar(100) DEFAULT NULL,
  `document_name` varchar(50) DEFAULT NULL,
  `application_date` varchar(50) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `travel_data`
--

INSERT INTO `travel_data` (`username`, `tid`, `first_name`, `last_name`, `designation`, `branch`, `max_da`, `max_lc`, `max_cc`, `p1_citytype`, `p1_fromstation`, `p1_tostation`, `p1_startdate`, `p1_enddate`, `p1_totaldays`, `p1_km`, `p1_daradio`, `p1_darate`, `p1_dadays`, `p1_dacharges`, `p1_lcradio`, `p1_lcrate`, `p1_lcdays`, `p1_lccharges`, `p1_ccradio`, `p1_ccrate`, `p1_ccdays`, `p1_cccharges`, `p1_ticketradio`, `p1_ticketcount`, `p1_ticketamount`, `p2_citytype`, `p2_fromstation`, `p2_tostation`, `p2_startdate`, `p2_enddate`, `p2_totaldays`, `p2_km`, `p2_daradio`, `p2_darate`, `p2_dadays`, `p2_dacharges`, `p2_lcradio`, `p2_lcrate`, `p2_lcdays`, `p2_lccharges`, `p2_ccradio`, `p2_ccrate`, `p2_ccdays`, `p2_cccharges`, `p2_ticketradio`, `p2_ticketcount`, `p2_ticketamount`, `p3_citytype`, `p3_fromstation`, `p3_tostation`, `p3_startdate`, `p3_enddate`, `p3_totaldays`, `p3_km`, `p3_daradio`, `p3_darate`, `p3_dadays`, `p3_dacharges`, `p3_lcradio`, `p3_lcrate`, `p3_lcdays`, `p3_lccharges`, `p3_ccradio`, `p3_ccrate`, `p3_ccdays`, `p3_cccharges`, `p3_ticketradio`, `p3_ticketcount`, `p3_ticketamount`, `p4_citytype`, `p4_fromstation`, `p4_tostation`, `p4_startdate`, `p4_enddate`, `p4_totaldays`, `p4_km`, `p4_daradio`, `p4_darate`, `p4_dadays`, `p4_dacharges`, `p4_lcradio`, `p4_lcrate`, `p4_lcdays`, `p4_lccharges`, `p4_ccradio`, `p4_ccrate`, `p4_ccdays`, `p4_cccharges`, `p4_ticketradio`, `p4_ticketcount`, `p4_ticketamount`, `lodging_bills`, `tickets_document`, `totalamount`, `remark`, `admin_comment`, `status`, `approval_date`, `document_name`, `application_date`) VALUES
('user', 1, 'Saurabh', 'Bonde', 'Officer', '9999 Head Office', 625, 1500, 375, 'Amravati', 'Akola', 'Amravati', '2023-11-10 11:00:00', '2023-11-12 05:00:00', 2, 200, 'No', 625, 2, 1250, 'No', 1500, 2, 3000, 'No', 375, 2, 750, 'No', 2, 200, '', '', '', NULL, NULL, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 5200, 'Testing', NULL, 'Rejected', '2023-11-28 18:19:03', 'fevicon_2.png', '2023-10-27 18:05:54'),
('john', 2, 'john', 'Doe', 'Officer', '9999 Head Office', 625, 1500, 375, 'Aurangabad', 'Akola', 'Aurangabad', '2023-10-01 11:00:00', '2023-10-03 05:10:00', 2, 500, 'No', 0, 0, 0, 'Yes', 5, 6, 30, 'No', 0, 0, 0, 'Yes', 2, 1000, '', '', '', NULL, NULL, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'htdocsw3logo.jpg', '', 1000, 'Hoollla', NULL, 'Rejected', '2023-11-01 14:36:09', 'fevicon.png', '2023-10-31 14:33:22'),
('user', 42, 'sachin', 'pardhi', 'Officer', '9999 Head Office', 625, 1500, 375, 'Nagpur', 'Akola', 'Nagpur', '2023-09-06 15:00:00', '2023-09-09 17:00:00', 3, 622, 'Yes', 625, 2, 1250, 'No', 0, 0, 0, 'Yes', 375, 2, 750, 'Yes', 3, 2707, '', '', '', NULL, NULL, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'fevicon_2.png', 4707, 'TA BILL', NULL, 'Approved', '2023-11-09 13:01:06', 'Prasad33.pdf', '2023-11-09 12:51:20'),
('user', 43, 'test', 'user1', 'Officer', '1001 Main Branch, Akola', 625, 1500, 375, 'Nanded', 'Akola', 'nanded', '2023-11-28 16:20:00', '2023-11-29 16:20:00', 1, 500, 'Yes', 625, 1, 625, 'No', 1500, 0, 0, 'Yes', 200, 1, 200, 'No', 0, 0, '', '', '', NULL, NULL, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 825, 'test user 1', NULL, 'Approved', '2024-06-26 16:21:20', 'Prasad33.pdf', '2023-11-28 16:21:08'),
('user', 44, 'Prasad', 'Ingle', 'Officer', '9999 Head Office', 1125, 2700, 675, 'Metro City', 'Akola', 'Amravati', '2024-03-02 17:32:00', '2024-03-03 17:32:00', 1, 520, 'Yes', 1125, 1, 1125, 'No', 2700, 0, 0, 'No', 0, 0, 0, 'No', 0, 0, 'District Centre', 'Amravati', 'Akola', '2024-03-03 17:32:00', '2024-03-04 17:32:00', 0, 87, 'No', 0, 0, 0, 'No', 0, 0, 0, 'No', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 1125, '4fgr', NULL, 'In Process', NULL, NULL, '2024-03-02 17:33:25'),
('user', 45, 'Prasad', 'Ingle', 'Officer', '9999 Head Office', 625, 1500, 375, 'Amravati', 'Akola', 'Ural', '2024-05-24 18:17:00', '2024-05-24 20:17:00', 0, 76, 'Yes', 625, 1, 625, 'No', 1500, 0, 0, 'Yes', 375, 1, 375, 'Yes', 2, 550, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Prasad.pdf', 'john_bill.pdf', 1550, 'test1 without keeping below forms field compulsory.', NULL, 'In Process', NULL, NULL, '2024-05-24 18:19:14'),
('user', 46, 'Prasad', 'Ingle', 'Officer', '9999 Head Office', NULL, NULL, NULL, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 'Screenshot (2).png', 'Screenshot (1).png', 9070, 'test', NULL, 'In Process', NULL, NULL, '2024-06-28 13:19:49'),
('user', 47, 'Christian', 'Shad', 'Dy. CEO/Chief Manager', '1009 Hiwarkhed', NULL, NULL, NULL, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', 0, 'Minim non sed et min', NULL, 'In Process', NULL, NULL, '2024-06-28 16:08:30'),
('user', 48, 'Prasad', 'Ingle', 'Officer', '9999 Head Office', NULL, NULL, NULL, 'Taluka and Below Centre', 'Akola', 'Daryapur', '0000-00-00 00:00:00', '2024-06-27 11:47:00', 2024, 1, 'Yes', 375, 1, 375, 'Yes', 900, 1, 900, 'Yes', 50, 1, 50, 'Yes', 2, 250, 'Amravati', 'Daryapur', 'Amravati', '0000-00-00 00:00:00', '2024-06-27 12:03:00', 2024, 1, 'Yes', 625, 1, 625, 'Yes', 1500, 1, 1500, 'Yes', 150, 1, 150, 0, 2, 300, 'District Centre', 'Amravati', 'Nagpur', '0000-00-00 00:00:00', '2024-06-29 12:03:00', 2024, 1, 'Yes', 500, 1, 500, 'Yes', 1200, 1, 1200, 'Yes', 200, 1, 200, '', 2, 300, 'Akola', 'Nagpur', 'Akola', '0000-00-00 00:00:00', '2024-06-30 12:04:00', 2024, 1, 'Yes', 625, 1, 625, 'Yes', 1500, 1, 1500, 'Yes', 40, 1, 40, 'Yes', 2, 555, 'Screenshot (5).png', '', 9070, 'Finaltest', NULL, 'In Process', NULL, NULL, '2024-06-28 16:49:03'),
('user', 49, 'Prasad', 'Ingle', 'Branch Head', '9999 Head Office', NULL, NULL, NULL, 'Taluka and Below Centre', 'Akola', 'Daryapur', '0000-00-00 00:00:00', '2024-06-28 16:57:00', 2024, 1, 'Yes', 375, 1, 375, 'Yes', 900, 1, 900, 'Yes', 101, 1, 101, 'No', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 1, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 1, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 1, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', 1386, 'jy', NULL, 'In Process', NULL, NULL, '2024-06-28 16:58:39'),
('user', 50, 'Gil', 'Alexander', 'Executive', '9999 Head Office', NULL, NULL, NULL, 'Metro City', 'Navarro', 'Hester', '2010-01-19 01:52:00', '1974-11-03 02:42:00', 27, 71, 'No', 750, 0, 0, 'No', 1800, 0, 0, 'Yes', 37, 4, 148, 'No', 0, 0, 'Nashik', 'King', 'Valencia', '1979-04-07 08:20:00', '1989-05-17 22:40:00', 28, 67, 'No', 500, 0, 0, 'Yes', 1200, 90, 0, 'No', 0, 0, 0, 0, 85, 45, 'Nashik', 'Sheppard', 'Jensen', '1988-10-07 04:51:00', '1985-04-08 17:04:00', 4, 4, 'Yes', 500, 58, 0, 'No', 1200, 0, 0, 'No', 0, 0, 0, 'Yes', 22, 64, 'Nagpur', 'Hunter', 'Meyer', '1988-03-01 09:50:00', '1983-04-01 11:38:00', 28, 88, 'No', 500, 0, 0, 'No', 1200, 0, 0, 'Yes', 89, 28, 2492, 'No', 0, 0, '', '', 0, 'Dolor quibusdam Nam ', NULL, 'In Process', NULL, NULL, '2024-06-28 17:02:19'),
('user', 51, 'Danielle', 'Raphael', 'Branch Head', '1028 Aurangabad', NULL, NULL, NULL, 'Metro City', 'Walsh', 'Slater', '1996-02-24 20:26:00', '1995-04-19 12:02:00', 9, 35, 'Yes', 1250, 32, 0, 'No', 3000, 0, 0, 'Yes', 40, 89, 3560, 'No', 0, 0, 'Amravati', 'Prince', 'Mccullough', '1985-01-08 18:55:00', '1989-07-07 15:24:00', 11, 85, 'Yes', 750, 63, 0, 'No', 1800, 0, 0, 'No', 0, 0, 0, 0, 2, 2, 'Akola', 'Collier', 'Robertson', '2008-03-27 10:37:00', '1991-06-02 01:33:00', 17, 23, 'No', 750, 0, 0, 'Yes', 1800, 3, 0, 'Yes', 16, 84, 1344, 'No', 0, 0, 'Metro City', 'Higgins', 'Warner', '2019-09-19 10:02:00', '2003-10-13 07:14:00', 24, 67, 'No', 1250, 0, 0, 'Yes', 3000, 2, 0, 'Yes', 25, 70, 1750, 'No', 0, 0, '', '', 0, 'Delectus cupiditate', NULL, 'In Process', NULL, NULL, '2024-06-29 12:32:19'),
('user', 52, 'Mona', 'Lana', 'Dy. CEO/Chief Manager', '1023 Chandrapur', NULL, NULL, NULL, 'District Centre', 'Kidd', 'Fowler', '2023-06-17 03:14:00', '2001-08-08 06:57:00', 6, 54, 'No', 625, 0, 0, 'No', 1500, 0, 0, 'No', 0, 0, 0, 'No', 0, 0, 'Indore', 'Mccarthy', 'Herring', '1972-09-01 13:54:00', '1984-04-23 13:17:00', 17, 28, 'No', 1000, 0, 0, 'No', 2400, 0, 0, 'No', 0, 0, 0, 0, 30, 48, 'Taluka and Below Centre', 'Rodgers', 'Key', '2014-01-09 03:46:00', '1985-11-02 00:15:00', 6, 52, 'No', 500, 0, 0, 'No', 1200, 0, 0, 'Yes', 74, 99, 7326, 'No', 0, 0, 'Aurangabad', 'Hendricks', 'Morin', '2003-03-20 16:52:00', '1998-05-02 14:57:00', 9, 84, 'Yes', 1000, 77, 0, 'Yes', 2400, 22, 0, 'No', 0, 0, 0, 'No', 0, 0, '', '', 0, 'Eveniet in asperior', NULL, 'In Process', NULL, NULL, '2024-06-29 12:33:44'),
('user', 53, 'Maya', 'Garth', 'Branch Head', '1016 Jaistambh Chowk, Amravati', NULL, NULL, NULL, 'Nagpur', 'Lancaster', 'Schroeder', '1971-02-13 22:45:00', '2004-10-28 07:12:00', 20, 51, 'No', 750, 0, 0, 'No', 1800, 0, 0, 'No', 0, 0, 0, 'No', 0, 0, 'Aurangabad', 'Stone', 'Decker', '1999-12-14 19:09:00', '2013-08-09 07:17:00', 9, 82, 'Yes', 750, 53, 0, 'No', 1800, 0, 0, 'No', 0, 0, 0, 0, 0, 0, 'District Centre', 'Case', 'Coffey', '1973-10-06 16:26:00', '1987-07-20 07:18:00', 5, 57, 'Yes', 500, 9, 0, 'No', 1200, 0, 0, 'Yes', 13, 10, 130, 'Yes', 25, 28, 'Nashik', 'Roth', 'Richardson', '2017-01-09 19:31:00', '1998-01-11 14:47:00', 21, 13, 'Yes', 750, 71, 0, 'No', 1800, 0, 0, 'No', 0, 0, 0, 'No', 0, 0, '', '', 0, 'Eligendi eveniet re', NULL, 'In Process', NULL, NULL, '2024-06-29 12:34:01'),
('user', 54, 'Audra', 'Alisa', '$designation', '1014 Sitabuldi,Nagpur', NULL, NULL, NULL, 'Metro City', 'Ferguson', 'Joyce', '2010-11-18 09:10:00', '2007-09-14 05:44:00', 13, 48, 'Yes', 0, 58, 0, 'Yes', 0, 21, 0, 'No', 0, 0, 0, 'No', 0, 0, 'Metro City', 'Henderson', 'Dominguez', '1974-12-01 19:16:00', '2006-05-06 17:51:00', 22, 68, 'Yes', 0, 79, 0, 'No', 0, 0, 0, 'Yes', 65, 8, 520, 0, 0, 0, 'Amravati', 'Downs', 'Day', '1973-12-11 15:44:00', '2024-07-13 15:21:00', 13, 11, 'Yes', 0, 49, 0, 'Yes', 0, 69, 0, 'Yes', 77, 69, 5313, 'Yes', 21, 23, 'Aurangabad', 'Giles', 'Lynn', '1975-10-03 22:31:00', '2002-12-02 04:05:00', 10, 31, 'Yes', 0, 42, 0, 'Yes', 0, 71, 0, 'Yes', 60, 82, 4920, 'No', 0, 0, '', '', 0, 'Est dolores eiusmod ', NULL, 'In Process', NULL, NULL, '2024-06-29 12:42:12'),
('user', 55, 'Lewis', 'Kamal', 'Messenger/Driver', '1021 Gandhibag,Nagpur', NULL, NULL, NULL, 'Amravati', 'May', 'Blair', '1997-02-15 09:10:00', '1995-10-13 07:29:00', 22, 85, 'No', 375, 0, 0, 'Yes', 900, 50, 0, 'No', 0, 0, 0, 'No', 0, 0, 'Aurangabad', 'Christian', 'Welch', '2018-07-27 12:59:00', '1987-01-20 08:13:00', 23, 23, 'Yes', 375, 30, 0, 'No', 900, 0, 0, 'No', 0, 0, 0, 0, 0, 0, 'Amravati', 'Merrill', 'Trevino', '1982-04-15 18:35:00', '1998-12-08 13:02:00', 5, 78, 'No', 375, 0, 0, 'Yes', 900, 92, 0, 'No', 0, 0, 0, 'No', 0, 0, 'Nagpur', 'Fry', 'Reynolds', '1974-09-02 11:44:00', '1976-08-21 09:45:00', 27, 94, 'Yes', 375, 66, 0, 'No', 900, 0, 0, 'Yes', 6, 42, 252, 'No', 0, 0, '', '', 0, 'Nostrud velit at mol', NULL, 'In Process', NULL, NULL, '2024-06-29 13:07:33'),
('user', 56, 'Amos', 'Sharon', 'Officer', '1018 Daryapur', NULL, NULL, NULL, 'Amravati', 'Mccoy', 'Hunt', '2020-07-20 17:30:00', '2008-04-23 20:02:00', 23, 52, 'No', 625, 0, 0, 'No', 1500, 0, 0, 'No', 0, 0, 0, 'Yes', 96, 9, 'Nanded', 'Garcia', 'Joseph', '1996-05-06 14:36:00', '2017-02-08 14:48:00', 13, 83, 'No', 625, 0, 0, 'No', 1500, 0, 0, 'Yes', 40, 12, 480, 0, 0, 0, 'Aurangabad', 'Andrews', 'Battle', '1991-10-13 07:15:00', '2010-12-26 23:14:00', 15, 95, 'Yes', 625, 30, 0, 'Yes', 1500, 87, 0, 'No', 0, 0, 0, 'No', 0, 0, 'Akola', 'Collier', 'Armstrong', '1971-09-12 06:09:00', '1987-12-26 13:34:00', 6, 91, 'Yes', 625, 59, 0, 'No', 1500, 0, 0, 'Yes', 76, 74, 5624, 'No', 0, 0, '', '', 0, 'In do fugit amet v', NULL, 'In Process', NULL, NULL, '2024-06-29 13:07:45'),
('user', 57, 'joh', 'doe', 'Officer', '1012 Wadegaon', NULL, NULL, NULL, 'Nagpur', 'Wadegaon', 'Nagpur', '2024-07-26 11:12:00', '2024-07-27 11:12:00', 1, 250, 'Yes', 625, 1, 625, 'No', 1500, 0, 0, 'Yes', 345, 2, 690, 'No', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', 0, 'test', NULL, 'In Process', NULL, NULL, '2024-07-26 11:13:23'),
('user', 58, 'Amaya', 'Maris', 'Branch Head', '1029 Nashik', NULL, NULL, NULL, 'Taluka and Below Centre', 'Vega', 'Booker', '2004-03-17 20:15:00', '1976-08-07 12:11:00', 20, 88, 'Yes', 375, 57, 0, 'Yes', 900, 46, 0, 'Yes', 21, 93, 1953, 'No', 0, 0, 'Nagpur', 'Rutledge', 'Koch', '1985-12-25 21:43:00', '2023-05-15 10:14:00', 8, 37, 'Yes', 750, 1, 750, 'No', 1800, 0, 0, 'Yes', 60, 29, 1740, 0, 0, 0, 'Akola', 'Frost', 'Price', '2019-05-23 13:59:00', '2018-09-07 06:50:00', 9, 62, 'Yes', 750, 85, 0, 'Yes', 1800, 11, 0, 'No', 0, 0, 0, 'Yes', 4, 63, 'District Centre', 'Gregory', 'Summers', '1973-10-13 15:36:00', '1976-04-01 20:44:00', 2, 52, 'No', 500, 0, 0, 'No', 1200, 0, 0, 'Yes', 89, 61, 5429, 'No', 0, 0, '', '', 9935, 'Voluptatem Distinct', NULL, 'In Process', NULL, NULL, '2024-07-26 11:18:41'),
('user', 59, 'Conan', 'Marshall', 'Branch Head', '1033 H.I.G. Colony,Indore', NULL, NULL, NULL, 'District Centre', 'Collins', 'Wilcox', '2006-12-12 19:31:00', '2013-10-19 05:26:00', 24, 65, 'Yes', 500, 100, 0, 'No', 1200, 0, 0, 'No', 0, 0, 0, 'No', 0, 0, 'Metro City', 'George', 'Aguirre', '1981-02-18 19:23:00', '1984-10-25 09:10:00', 26, 79, 'Yes', 1250, 55, 0, 'No', 3000, 0, 0, 'No', 0, 0, 0, 0, 0, 0, 'Nashik', 'Guy', 'Lawson', '2020-03-08 01:17:00', '2009-08-16 05:50:00', 23, 53, 'Yes', 750, 66, 0, 'No', 1800, 0, 0, 'Yes', 77, 20, 1540, 'Yes', 3, 4, 'District Centre', 'Bishop', 'Joseph', '1989-05-08 15:28:00', '1982-06-27 13:47:00', 26, 16, 'No', 500, 0, 0, 'Yes', 1200, 61, 0, 'No', 0, 0, 0, 'No', 0, 0, '', '', 1544, 'Nihil eveniet nulla', NULL, 'In Process', NULL, NULL, '2024-07-26 11:25:15');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_number` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `create_date` varchar(50) NOT NULL,
  `role` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `username`, `email`, `mobile_number`, `password`, `create_date`, `role`) VALUES
(1, 'Test_user', 'admin', 'admin@gmail.com', '1215515', 'Test@123', '2023-08-10', ''),
(2, '', 'user', 'pdingle@gmail.com', '', 'Prasad@123', '2023-08-18 08:18:07', 'user'),
(10, '', 'john', 'johnHHH@gmail.com', '', '9921', '2023-10-31 09:51:13', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD UNIQUE KEY `br_id` (`br_id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `travel_data`
--
ALTER TABLE `travel_data`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `c_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `travel_data`
--
ALTER TABLE `travel_data`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
