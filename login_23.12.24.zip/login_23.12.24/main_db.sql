-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2025 at 02:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `br_id` int(11) NOT NULL,
  `br_name` varchar(256) NOT NULL,
  `br_address` varchar(512) NOT NULL,
  `br_mail` varchar(50) NOT NULL,
  `br_phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`br_id`, `br_name`, `br_address`, `br_mail`, `br_phone`) VALUES
(1001, 'Main Branch, Akola', '\'JANKALYAN\' OLD COTTON MARKET, AKOLA-444 001', 'aucb_main@aucbakola.com', '7242442251'),
(1002, 'Ramdaspeth,Akola', 'DATTA MANDIR CHOWK, RAMDAS PETH, AKOLA - 444 001', 'aucb_ramdaspeth@aucbakola.com', '7242434543'),
(1003, 'Karanja', 'MAIN RD, COTTON MARKET, NEAR APMC. KARANJA - 444 105', 'aucb_karnja@aucbakola.com', '7256222126'),
(1004, 'Mangrulpir', 'INFRONT OF SBI MAIN RD, MANGRULPIR - 444 403', 'aucb_mangrulpir@aucbakola.com', '7253230255'),
(1005, 'Adarsh Colony,Akola', 'POONAM COMPLEX,  GORAKSHAN RD, INCOME TAX CHOWK, AKOLA 444 004', 'aucb_adarshcolony@aucbakola.com', '7242459536'),
(1006, 'Balapur ', 'NEAR STATE BANK OF INDIA, BALAPUR DIST. AKOLA - 444 302', 'aucb_balapur@aucbakola.com', '7257232116'),
(1007, 'Tajnapeth,Akola', 'NEAR HDFC BANK, JILLHA PARISHAD ROAD, AKOLA - 444 001', 'aucb_tajnapeth@aucbakola.com', '7242438304'),
(1008, 'Murtizapur ', 'STATION ROAD, MURTIZAPUR  DIST AKOLA 444 107', 'aucb_murtizapur@aucbakola.com', '07256 243552'),
(1009, 'Hiwarkhed', 'MAIN ROAD, HIWARKHED 444103', 'aucb_hiwarkhed@aucbakola.com', '7258228209'),
(1010, 'Akot', 'LAKKAD GUNJ, HIWARKHED RD, AKOT DIST AKOLA - 444 101', 'aucb_akot@aucbakola.com', '7258224184'),
(1011, 'Malegaon', 'SHRI NAWASTHALE BUILDING MAIN RD. MALEGAON - 444 503', 'aucb_malegaon@aucbakola.com', '7254231271'),
(1012, 'Wadegaon', 'SHRI JAYRAM KALE COMPLEX, MAIN RD, WADEGAON - 444 502', 'aucb_wadegaon@aucbakola.com', '7257231144'),
(1013, 'Telhara', 'INFRONT OF  SHIVAJI SCHOOL, BUS STAND ROAD, TELHARA - 444 108', 'aucb_telhara@aucbakola.com', '7258231030'),
(1014, 'Sitabuldi,Nagpur', 'SAGAR TOWER, 2ND FLOOR, BESIDE NARESHCHANDRA & CO. PANDIT MALVIYA RD, SITABULDI, NAGPUR - 440 012', 'aucb_sitabuldi@aucbakola.com', '7122527199'),
(1015, 'Jalgaon', 'NATRAJ HALL OPP.PADMALAYA GOVT. REST HOUSE, JAYKISANWADI JALGAON - 425 001', 'aucb_jalgaon@aucbakola.com', '2572220197'),
(1016, 'Jaistambh Chowk, Amravati', 'MAHAVIR PLAZA COMPLEX, JAISTAMBH CHOWK, AMRAVATI - 444 601', 'aucb_jaisthambh@aucbakola.com', '7212679911'),
(1017, 'Yavatmal', 'SHARDA SADAN, AWDHOOT WADI, YAVATMAL - 445001', 'aucb_yavatmal@aucbakola.com', '7232241358'),
(1018, 'Daryapur', 'BANOSA ROAD, DARYAPUR - 444 803', 'aucb_daryapur@aucbakola.com', '7224234782'),
(1019, 'Rajapeth,Amravati', 'DEORANKAR NAGAR,NEAR SAMARTH HIGHSCHOOL,BADNERA ROAD, RAJAPETH AMRAVATI - 444601\r\n\r\n\r\n\r\n\r\n\r\n', 'aucb_rajapeth@aucbakola.com', '7212575501'),
(1020, 'Kalbadevi,Mumbai', '19,21/23 KARNANI HOUSE, VITHOBA LANE, VITTHALWADI, MUMBAI - 400 002', 'aucb_kalbadevi@aucbakola.com', '222406259'),
(1021, 'Gandhibag,Nagpur', '2ND FLOOR AHILYA COMPLEX NEAR MEDICINE MARKET AGRESEN CHOWK GANDHIBAG, NAGPUR - 440 002', 'aucb_gandhibag@aucbakola.com', '7122732750'),
(1022, 'APMC,Akola', 'GANGA NAGAR,BALAPUR ROAD,AKOLA - 444 001', 'aucb_apmc@aucbakola.com', '7242442250'),
(1023, 'Chandrapur', 'RAMKRUSHNA APPTT. GANJ WARD, CHANDRAPUR - 442 402', 'aucb_chandrapur@aucbakola.com', '7172256551'),
(1024, 'Wardha', 'RADHE COMPLEX SOCIELIST CHOWK, WARDHA - 442 008', 'aucb_wardha@aucbakola.com', '7152244554'),
(1025, 'Nanded', 'GROUND FLOOR, PATIL PLAZA, TAJ PATIL HOTEL,VISHNU COMPLEX, VIP ROAD,NANDED - 431605\r\n', 'aucb_nanded@aucbakola.com', '2462250370'),
(1026, 'Dabki Road,Akola', 'NEAR BHIKAMCHAND, KHANDELWAL HIGH SCHOOL,  GODBOLE PLOTS, DABKI ROAD, AKOLA - 444 002', 'aucb_dabkiroad@aucbakola.com', '7242439616'),
(1027, 'Civil Line,Akola ', '\'MAHALAXMI\'COMPLEX, OPP.BAGDI HOSITAL,AMANKHA PLOT,AKOLA-444001', 'aucb_civilline@aucbakola.com', '7242453317'),
(1028, 'Aurangabad', 'GOPICHAND COMPLEX, OPP. APNA HOSPITAL JALNA RD, AURANGABAD - 431 001', 'aucb_aurangabad@aucbakola.com', '2402344500'),
(1029, 'Nashik', 'NEAR MEHAR PLAZA BUILDING SAMANT HOUSE, ABOVE INDIAN BANK, OLD AGRA ROAD, NASHIK - 422 002', 'aucb_nasik@aucbakola.com', '2532318147'),
(1030, 'Brahman Sabha,Akola', 'JATHARPETH CHOWK, NEAR UTSAV MANGALKARYALAYA, AKOLA - 444 001', 'aucb_bsec@aucbakola.com', '7242490561'),
(1031, 'Subhashmarg,Indore', 'NETAJI SHUBHSAH MARG, INDORE -  452 007', 'aucb_subhashmarg@aucbakola.com', '7312531594'),
(1032, 'Malharganj,Indore', '19/2 DALLAI PATTI MALHARGANJ, INDORE- 452 002', 'aucb_malharganj@aucbakola.com', '7312411668'),
(1033, 'H.I.G. Colony,Indore', 'S-43, BEHIND KHRISTAN EMINENT SCHOOL MIG COLONY, INDORE - 452 010', 'aucb_higcolony@aucbakola.com', '7312553888'),
(1034, 'Sanyogitaganj,Indore', '47/2 SANYOGITA GANJ INDORE - 452 007', 'aucb_sanyogitaganj@aucbakola.com', '7312702355'),
(9999, 'Head Office', 'Jankalyan, 58-59, Toshniwal Layout, Near Govt. Milk Scheme, Murtizapur Road, Akola', 'aucb_main@aucbakola.com', '2453850-54');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `c_id` int(50) NOT NULL,
  `city_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`c_id`, `city_name`) VALUES
(1, 'Metro City'),
(2, 'District Centre'),
(3, 'Taluka and Below Centre'),
(4, 'Nagpur'),
(5, 'Nashik'),
(6, 'Aurangabad'),
(7, 'Nanded'),
(8, 'Akola'),
(9, 'Amravati'),
(10, 'Indore');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `d_id` int(11) NOT NULL,
  `designation_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`d_id`, `designation_name`) VALUES
(1, 'Dy. CEO/Chief Manager'),
(3, 'Branch Head'),
(5, 'Officer'),
(6, 'Executive'),
(7, 'Messenger/Driver');

-- --------------------------------------------------------

--
-- Table structure for table `passing_officers`
--

CREATE TABLE `passing_officers` (
  `po_id` int(11) NOT NULL,
  `po_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passing_officers`
--

INSERT INTO `passing_officers` (`po_id`, `po_name`) VALUES
(1, 'Sunil Shejole'),
(2, 'Mangesh Alkari'),
(3, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `travel_data`
--

CREATE TABLE `travel_data` (
  `username` varchar(50) DEFAULT NULL,
  `tid` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `designation` text DEFAULT NULL,
  `branch` text DEFAULT NULL,
  `passing_officer` varchar(50) DEFAULT NULL,
  `max_da` int(100) DEFAULT NULL,
  `max_lc` int(100) DEFAULT NULL,
  `max_cc` int(100) DEFAULT NULL,
  `p1_citytype` varchar(50) DEFAULT NULL,
  `p1_fromstation` varchar(50) DEFAULT NULL,
  `p1_tostation` varchar(50) DEFAULT NULL,
  `p1_startdate` datetime DEFAULT NULL,
  `p1_enddate` datetime DEFAULT NULL,
  `p1_totaldays` int(20) DEFAULT NULL,
  `p1_km` int(100) DEFAULT NULL,
  `p1_daradio` varchar(5) DEFAULT NULL,
  `p1_darate` int(50) DEFAULT NULL,
  `p1_dadays` int(50) DEFAULT NULL,
  `p1_dacharges` int(50) DEFAULT NULL,
  `p1_lcradio` varchar(5) DEFAULT NULL,
  `p1_lcrate` int(50) DEFAULT NULL,
  `p1_lcdays` int(50) DEFAULT NULL,
  `p1_lccharges` int(50) DEFAULT NULL,
  `p1_ccradio` varchar(5) DEFAULT NULL,
  `p1_ccrate` int(50) DEFAULT NULL,
  `p1_ccdays` int(50) DEFAULT NULL,
  `p1_cccharges` int(50) DEFAULT NULL,
  `p1_ticketradio` varchar(5) DEFAULT NULL,
  `p1_ticketcount` int(50) DEFAULT NULL,
  `p1_ticketamount` int(50) DEFAULT NULL,
  `p2_citytype` text DEFAULT NULL,
  `p2_fromstation` varchar(50) DEFAULT NULL,
  `p2_tostation` varchar(50) DEFAULT NULL,
  `p2_startdate` datetime DEFAULT NULL,
  `p2_enddate` datetime DEFAULT NULL,
  `p2_totaldays` int(20) DEFAULT NULL,
  `p2_km` int(100) DEFAULT NULL,
  `p2_daradio` varchar(5) DEFAULT NULL,
  `p2_darate` int(50) DEFAULT NULL,
  `p2_dadays` int(50) DEFAULT NULL,
  `p2_dacharges` int(50) DEFAULT NULL,
  `p2_lcradio` varchar(5) DEFAULT NULL,
  `p2_lcrate` int(50) DEFAULT NULL,
  `p2_lcdays` int(50) DEFAULT NULL,
  `p2_lccharges` int(50) DEFAULT NULL,
  `p2_ccradio` varchar(5) DEFAULT NULL,
  `p2_ccrate` int(50) DEFAULT NULL,
  `p2_ccdays` int(50) DEFAULT NULL,
  `p2_cccharges` int(50) DEFAULT NULL,
  `p2_ticketradio` int(10) DEFAULT NULL,
  `p2_ticketcount` int(10) DEFAULT NULL,
  `p2_ticketamount` int(10) DEFAULT NULL,
  `p3_citytype` varchar(50) DEFAULT NULL,
  `p3_fromstation` varchar(50) DEFAULT NULL,
  `p3_tostation` varchar(50) DEFAULT NULL,
  `p3_startdate` datetime DEFAULT NULL,
  `p3_enddate` datetime DEFAULT NULL,
  `p3_totaldays` int(20) DEFAULT NULL,
  `p3_km` int(100) DEFAULT NULL,
  `p3_daradio` varchar(5) DEFAULT NULL,
  `p3_darate` int(50) DEFAULT NULL,
  `p3_dadays` int(50) DEFAULT NULL,
  `p3_dacharges` int(50) DEFAULT NULL,
  `p3_lcradio` varchar(5) DEFAULT NULL,
  `p3_lcrate` int(50) DEFAULT NULL,
  `p3_lcdays` int(50) DEFAULT NULL,
  `p3_lccharges` int(50) DEFAULT NULL,
  `p3_ccradio` varchar(5) DEFAULT NULL,
  `p3_ccrate` int(50) DEFAULT NULL,
  `p3_ccdays` int(50) DEFAULT NULL,
  `p3_cccharges` int(50) DEFAULT NULL,
  `p3_ticketradio` varchar(5) DEFAULT NULL,
  `p3_ticketcount` int(50) DEFAULT NULL,
  `p3_ticketamount` int(50) DEFAULT NULL,
  `p4_citytype` varchar(100) DEFAULT NULL,
  `p4_fromstation` varchar(100) DEFAULT NULL,
  `p4_tostation` varchar(100) DEFAULT NULL,
  `p4_startdate` datetime DEFAULT NULL,
  `p4_enddate` datetime DEFAULT NULL,
  `p4_totaldays` int(10) DEFAULT NULL,
  `p4_km` int(10) DEFAULT NULL,
  `p4_daradio` varchar(5) DEFAULT NULL,
  `p4_darate` int(10) DEFAULT NULL,
  `p4_dadays` int(10) DEFAULT NULL,
  `p4_dacharges` int(10) DEFAULT NULL,
  `p4_lcradio` varchar(5) DEFAULT NULL,
  `p4_lcrate` int(10) DEFAULT NULL,
  `p4_lcdays` int(10) DEFAULT NULL,
  `p4_lccharges` int(10) DEFAULT NULL,
  `p4_ccradio` varchar(5) DEFAULT NULL,
  `p4_ccrate` int(10) DEFAULT NULL,
  `p4_ccdays` int(10) DEFAULT NULL,
  `p4_cccharges` int(10) DEFAULT NULL,
  `p4_ticketradio` varchar(5) DEFAULT NULL,
  `p4_ticketcount` int(10) DEFAULT NULL,
  `p4_ticketamount` int(10) DEFAULT NULL,
  `lodging_bills` varchar(100) DEFAULT NULL,
  `tickets_document` varchar(100) DEFAULT NULL,
  `totalamount` int(50) NOT NULL,
  `remark` text DEFAULT NULL,
  `admin_comment` varchar(100) DEFAULT NULL,
  `manager_approval` text NOT NULL,
  `admin_approval` text NOT NULL,
  `approval_date` varchar(100) DEFAULT NULL,
  `document_name` varchar(50) DEFAULT NULL,
  `application_date` varchar(50) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `travel_data`
--

INSERT INTO `travel_data` (`username`, `tid`, `first_name`, `last_name`, `designation`, `branch`, `passing_officer`, `max_da`, `max_lc`, `max_cc`, `p1_citytype`, `p1_fromstation`, `p1_tostation`, `p1_startdate`, `p1_enddate`, `p1_totaldays`, `p1_km`, `p1_daradio`, `p1_darate`, `p1_dadays`, `p1_dacharges`, `p1_lcradio`, `p1_lcrate`, `p1_lcdays`, `p1_lccharges`, `p1_ccradio`, `p1_ccrate`, `p1_ccdays`, `p1_cccharges`, `p1_ticketradio`, `p1_ticketcount`, `p1_ticketamount`, `p2_citytype`, `p2_fromstation`, `p2_tostation`, `p2_startdate`, `p2_enddate`, `p2_totaldays`, `p2_km`, `p2_daradio`, `p2_darate`, `p2_dadays`, `p2_dacharges`, `p2_lcradio`, `p2_lcrate`, `p2_lcdays`, `p2_lccharges`, `p2_ccradio`, `p2_ccrate`, `p2_ccdays`, `p2_cccharges`, `p2_ticketradio`, `p2_ticketcount`, `p2_ticketamount`, `p3_citytype`, `p3_fromstation`, `p3_tostation`, `p3_startdate`, `p3_enddate`, `p3_totaldays`, `p3_km`, `p3_daradio`, `p3_darate`, `p3_dadays`, `p3_dacharges`, `p3_lcradio`, `p3_lcrate`, `p3_lcdays`, `p3_lccharges`, `p3_ccradio`, `p3_ccrate`, `p3_ccdays`, `p3_cccharges`, `p3_ticketradio`, `p3_ticketcount`, `p3_ticketamount`, `p4_citytype`, `p4_fromstation`, `p4_tostation`, `p4_startdate`, `p4_enddate`, `p4_totaldays`, `p4_km`, `p4_daradio`, `p4_darate`, `p4_dadays`, `p4_dacharges`, `p4_lcradio`, `p4_lcrate`, `p4_lcdays`, `p4_lccharges`, `p4_ccradio`, `p4_ccrate`, `p4_ccdays`, `p4_cccharges`, `p4_ticketradio`, `p4_ticketcount`, `p4_ticketamount`, `lodging_bills`, `tickets_document`, `totalamount`, `remark`, `admin_comment`, `manager_approval`, `admin_approval`, `approval_date`, `document_name`, `application_date`) VALUES
('user', 1, 'Saurabh', 'Bonde', 'Officer', '9999 Head Office', '', 625, 1500, 375, 'Amravati', 'Akola', 'Amravati', '2023-11-10 11:00:00', '2023-11-12 05:00:00', 2, 200, 'No', 625, 2, 1250, 'No', 1500, 2, 3000, 'No', 375, 2, 750, 'No', 2, 200, '', '', '', NULL, NULL, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 5200, 'Testing', NULL, 'Rejected', '', '2023-11-28 18:19:03', 'fevicon_2.png', '2023-10-27 18:05:54'),
('john', 2, 'john', 'Doe', 'Officer', '9999 Head Office', 'Sunil Shejole', 625, 1500, 375, 'Aurangabad', 'Akola', 'Aurangabad', '2023-10-01 11:00:00', '2023-10-03 05:10:00', 2, 500, 'No', 0, 0, 0, 'Yes', 5, 6, 30, 'No', 0, 0, 0, 'Yes', 2, 1000, '', '', '', NULL, NULL, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'htdocsw3logo.jpg', '', 1000, 'Hoollla', NULL, '', '', '', 'fevicon.png', '2023-10-31 14:33:22'),
('user', 74, 'om', 'kajanae', 'Dy. CEO/Chief Manager', '1001 Main Branch, Akola', 'Sunil Shejole', NULL, NULL, NULL, 'Metro City', 'shegaon', 'delhi', '2024-11-09 12:31:00', '2024-11-11 12:31:00', 2, 1001, 'Yes', 1500, 1, 1500, 'Yes', 3600, 1, 3600, 'Yes', 250, 1, 250, 'Yes', 2, 1100, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', 6450, 'test 09.11.2024', NULL, 'Approved', 'Rejected', NULL, 'Media (3).jpg', '2024-11-09 12:32:52'),
('user', 75, 'PRASAD', 'INGLE', 'Officer', '1005 Adarsh Colony,Akola', 'Sunil Shejole', NULL, NULL, NULL, 'Akola', 'Akola', 'Shegaon', '2025-01-04 17:24:00', '2025-01-05 17:24:00', 1, 243, 'Yes', 625, 1, 625, 'No', 1500, 0, 0, 'Yes', 13, 13, 169, 'No', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', 794, 'wdf', NULL, 'In Process', '', NULL, 'UTR no insertion.png', '2025-01-04 17:24:43'),
(NULL, 78, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1736143358_AUCB Agency Banking.jpg', NULL, 0, NULL, NULL, '', '', NULL, NULL, '2025-01-06 11:32:38'),
('user', 79, 'om', 'ticket', 'Executive', '1005 Adarsh Colony,Akola', 'admin', NULL, NULL, NULL, 'Taluka and Below Centre', 'Murtizapur', 'Nashik', '2025-01-06 11:31:00', '2025-01-09 11:31:00', 3, 23, 'Yes', 300, 2, 600, 'Yes', 720, 2, 1440, 'Yes', 323, 2, 646, 'Yes', 2, 600, '', '', '', NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '1736143358_AUCB Agency Banking.jpg', '', 3286, 'tah', NULL, 'In Process', '', NULL, 'om_TA_Bill.pdf', '2025-01-06 11:32:38'),
(NULL, 80, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1736163976_Screenshot 2.jpg', NULL, 0, NULL, NULL, '', '', NULL, NULL, '2025-01-06 17:16:16'),
('user', 81, 'Karan', 'Joshi', 'Officer', '1010 Akot', 'Sunil Shejole', NULL, NULL, NULL, 'Nagpur', 'Akola', 'Nashik', '2025-01-06 17:14:00', '2025-01-07 17:14:00', 1, 4, 'Yes', 625, 1, 625, 'Yes', 1500, 1, 1500, 'Yes', 21, 1, 21, 'Yes', 1, 212, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '1736163976_Screenshot 2.jpg', '', 2358, 'sdfs', NULL, 'In Process', '', NULL, 'UTR no insertion.png', '2025-01-06 17:16:16'),
('user', 82, 'man', 'karnika', 'Officer', '1006 Balapur ', '', NULL, NULL, NULL, 'Taluka and Below Centre', 'kjbndf', 'jkbnsdfa', '2025-01-28 19:39:00', '2025-01-30 19:40:00', 2, 897, 'Yes', 375, 1, 375, 'Yes', 900, 1, 900, 'Yes', 21, 1, 21, 'Yes', 2, 213, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', 1509, 'f', NULL, 'In Process', '', NULL, 'Media (2).jpg', '2025-01-29 19:40:20'),
('user', 83, 'Prasad', 'karnik', 'Executive', '1004 Mangrulpir', '', NULL, NULL, NULL, 'Taluka and Below Centre', 'kjbndf', 'jkbnsdfa', '2025-01-29 17:45:00', '2025-01-30 17:45:00', 1, 897, 'Yes', 300, 2, 600, 'Yes', 720, 2, 1440, 'Yes', 213, 2, 426, 'Yes', 21, 22, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 0, '', '', 2488, '3', NULL, 'In Process', '', NULL, NULL, '2025-01-30 17:46:02');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_number` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `create_date` varchar(50) NOT NULL,
  `role` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `username`, `email`, `mobile_number`, `password`, `create_date`, `role`) VALUES
(1, 'Test_user', 'admin', 'admin@gmail.com', '1215515', 'Test@123', '2023-08-10', 'admin'),
(2, '', 'user', 'pdingle@gmail.com', '', 'Prasad@123', '2023-08-18 08:18:07', 'user'),
(10, '', 'john', 'johnHHH@gmail.com', '', '9921', '2023-10-31 09:51:13', 'user'),
(11, '', 'mangesh', 'mangesh@gmail.com', '', 'ta@123', '2024-09-22 20:55:44', 'user'),
(12, '', 'Sunil Shejole', 'sv.shejole@aucbakola.com', '', 'Aucb@123', '2024-11-09 09:14:38', 'manager');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD UNIQUE KEY `br_id` (`br_id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `passing_officers`
--
ALTER TABLE `passing_officers`
  ADD PRIMARY KEY (`po_id`);

--
-- Indexes for table `travel_data`
--
ALTER TABLE `travel_data`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `c_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `passing_officers`
--
ALTER TABLE `passing_officers`
  MODIFY `po_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `travel_data`
--
ALTER TABLE `travel_data`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
